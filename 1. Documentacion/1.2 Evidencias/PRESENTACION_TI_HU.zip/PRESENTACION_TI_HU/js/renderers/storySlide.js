/**
 * ============================================================================
 * RENDERIZADOR: DIAPOSITIVA DE HISTORIA DE USUARIO (HU-01..HU-18) · VERSIÓN SINTETIZADA
 * Muestra en pantalla solo ideas clave (BRIEFS). El texto completo de stories.js
 * queda disponible como tooltip al pasar el mouse sobre cada regla / criterio.
 * ============================================================================
 */
window.PresentationApp = window.PresentationApp || {};
window.PresentationApp.Renderers = window.PresentationApp.Renderers || {};

window.PresentationApp.Renderers.storySlide = function renderStorySlide(story, slideNum, totalSlides) {
  const { CONFIG, UI, BRIEFS } = window.PresentationApp;
  const { escapeHtml: esc, renderTopbar, renderFooter } = UI;
  const brief = BRIEFS[story.id];

  const investKeys = [
    { key: 'I', label: 'Independiente' },
    { key: 'N', label: 'Negociable' },
    { key: 'V', label: 'Valiosa' },
    { key: 'E', label: 'Estimable' },
    { key: 'S', label: 'Pequeña' },
    { key: 'T', label: 'Verificable' }
  ];

  const moscowText = CONFIG.moscowLabels[story.moscow] || story.moscow;
  const roleShort = story.role.startsWith('Prop') ? 'Propietaria' : 'Operadora';
  // Fuente corta: solo los requisitos (RF/RNF/RN), sin las referencias DEC del acta
  const sourceShort = story.source.split(' · ')[0];

  return `
    <section
      class="slide hu-slide"
      data-story-id="${story.id}"
      data-slide-title="${story.id}: ${esc(story.title)}"
      data-slide-group="${esc(story.epic)}"
    >
      ${renderTopbar(`Historia de Usuario · ${story.epic}`)}

      <div class="slide-body hu-body">
        <!-- Cabecera -->
        <header class="hu-head">
          <div class="hu-id">${story.id}</div>
          <div class="hu-head-text">
            <h2 class="hu-title">${esc(story.title)}</h2>
            <div class="hu-meta">
              <span>${esc(story.epic)}</span>
              <span><b>Depende:</b> ${esc(story.dependsOn)}</span>
              <span><b>Fuente:</b> ${esc(sourceShort)}</span>
              <span class="hu-meta-ui" title="${esc(story.uiNote)}"><b>Pantalla:</b> ${esc(brief.ui)}</span>
            </div>
          </div>
          <div class="hu-badges">
            <span class="badge badge-moscow-${story.moscow}">${moscowText}</span>
            <span class="badge badge-neutral">${story.points} pts</span>
            <span class="badge badge-neutral">Valor ${story.businessValue}</span>
            <span class="badge badge-risk-${story.techRisk}">Riesgo ${story.techRisk}</span>
          </div>
        </header>

        <!-- 1C Tarjeta + 2C Reglas -->
        <div class="hu-row">
          <div class="hu-card" title="Como ${esc(story.card.como)}, quiero ${esc(story.card.quiero)}, para ${esc(story.card.para)}.">
            <div class="hu-label"><span class="hu-c">1C</span> Tarjeta</div>
            <div class="hu-card-line"><span class="hu-kw">Como</span><span class="hu-role">${roleShort}</span></div>
            <div class="hu-card-line"><span class="hu-kw">Quiero</span><span>${esc(brief.quiero)}</span></div>
            <div class="hu-card-line"><span class="hu-kw">Para</span><span>${esc(brief.para)}</span></div>
          </div>

          <div class="hu-panel">
            <div class="hu-label"><span class="hu-c">2C</span> Reglas clave</div>
            <ul class="hu-rules">
              ${brief.rules.map(([kw, txt], i) => `
                <li title="${esc(story.rules[i] ? story.rules[i].text : '')}">
                  <strong>${esc(kw)}</strong><span>${esc(txt)}</span>
                </li>
              `).join('')}
            </ul>
          </div>
        </div>

        <!-- 3C Criterios Gherkin en tabla -->
        <div class="hu-panel hu-criteria">
          <div class="hu-label"><span class="hu-c">3C</span> Criterios de aceptación <em>Gherkin</em></div>
          <table class="hu-table">
            <thead>
              <tr><th>Escenario</th><th>Dado</th><th>Cuando</th><th>Entonces</th></tr>
            </thead>
            <tbody>
              ${brief.ca.map(([name, dado, cuando, entonces], i) => {
                const full = story.criteria[i];
                const tip = full ? `Dado que ${full.dado}; cuando ${full.cuando}; entonces ${full.entonces}.` : '';
                return `
                  <tr title="${esc(tip)}">
                    <td><span class="hu-ca-id">CA-${String(i + 1).padStart(2, '0')}</span>${esc(name)}</td>
                    <td>${esc(dado)}</td>
                    <td>${esc(cuando)}</td>
                    <td class="hu-then">${esc(entonces)}</td>
                  </tr>
                `;
              }).join('')}
            </tbody>
          </table>
        </div>

        <!-- RNF + INVEST -->
        <div class="hu-strip">
          <div class="hu-strip-group">
            <span class="hu-strip-label">RNF</span>
            ${brief.rnf.map(([cat, m]) => `<span class="hu-chip"><b>${esc(cat)}</b> ${esc(m)}</span>`).join('')}
          </div>
          <div class="hu-strip-group">
            <span class="hu-strip-label">INVEST</span>
            ${investKeys.map((item) => {
              const ok = Boolean(story.invest[item.key]);
              return `<span class="invest-pill ${ok ? 'is-yes' : 'is-no'}" title="${item.label}: ${ok ? 'Cumple' : 'Dependencia / pendiente'}">${item.key}</span>`;
            }).join('')}
          </div>
        </div>
      </div>

      ${renderFooter(slideNum, totalSlides, story.id)}
    </section>
  `;
};
