/**
 * ============================================================================
 * RENDERIZADORES: CONTEXTO, FLUJO DIVISAS, STAKEHOLDERS, ÉPICAS, TRAZABILIDAD, CIERRE
 * Versión sintetizada: ideas y palabras clave, tipografía grande.
 * ============================================================================
 */
window.PresentationApp = window.PresentationApp || {};
window.PresentationApp.Renderers = window.PresentationApp.Renderers || {};

/* ---------- 2. CONTEXTO Y ENFOQUE 3C ---------- */
window.PresentationApp.Renderers.contextSlide = function renderContextSlide(slideNum, totalSlides) {
  const { CONTEXT } = window.PresentationApp;
  const { renderTopbar, renderFooter } = window.PresentationApp.UI;

  const kpis = [
    { value: '18', label: 'Historias de Usuario', sub: 'RF-01…RF-20 + RN-03', accent: '' },
    { value: '20', label: 'Requisitos funcionales', sub: 'ENT-01 · v1.1 · 18/11/2026', accent: '' },
    { value: '6', label: 'Divisas → USD', sub: 'EUR · COP · PEN · BRL · GBP · CLP', accent: 'is-gold' },
    { value: '2', label: 'Ventanillas en paralelo', sub: 'Operan incluso sin Internet', accent: 'is-red' }
  ];

  const threeC = [
    { code: '1C', title: 'Tarjeta', key: 'Como · Quiero · Para', sub: 'Rol, necesidad y valor' },
    { code: '2C', title: 'Conversación', key: 'Reglas y acuerdos con E1', sub: 'Puntos abiertos P-01…P-12' },
    { code: '3C', title: 'Confirmación', key: 'Criterios Gherkin', sub: 'Dado · Cuando · Entonces + ISO 25010' }
  ];

  const moscowShort = {
    M: 'Núcleo operativo',
    S: 'Controles y recuperación',
    C: 'Mejoras deseables',
    W: 'UAFE · sujeto a P-02'
  };

  return `
    <section class="slide" data-slide-title="Contexto y Metodología 3C" data-slide-group="Introducción">
      ${renderTopbar('Contexto · Entrevista ENT-01')}
      <div class="slide-body ov-body">
        <div class="eyebrow">Técnica de Elicitación</div>
        <h2 class="slide-heading">Entrevista ENT-01 → 18 Historias de Usuario</h2>

        <div class="ov-kpis">
          ${kpis.map((k) => `
            <div class="ov-kpi ${k.accent}">
              <div class="ov-kpi-value">${k.value}</div>
              <div class="ov-kpi-label">${k.label}</div>
              <div class="ov-kpi-sub">${k.sub}</div>
            </div>
          `).join('')}
        </div>

        <div class="ov-section-label">Enfoque 3C en cada historia</div>
        <div class="ov-3c">
          ${threeC.map((c) => `
            <div class="ov-3c-card">
              <div class="ov-3c-code">${c.code}</div>
              <div>
                <div class="ov-3c-title">${c.title}</div>
                <div class="ov-3c-key">${c.key}</div>
                <div class="ov-3c-sub">${c.sub}</div>
              </div>
            </div>
          `).join('')}
        </div>

        <div class="ov-section-label">Priorización MoSCoW</div>
        <div class="ov-moscow">
          ${CONTEXT.moscowSummary.map((m) => `
            <div class="ov-moscow-seg ov-moscow-${m.code}" style="flex:${m.count + 2};">
              <span class="ov-moscow-num">${m.count}</span>
              <span class="ov-moscow-txt"><b>${m.code} · ${m.label.split(' (')[0]}</b>${moscowShort[m.code]}</span>
            </div>
          `).join('')}
        </div>
      </div>
      ${renderFooter(slideNum, totalSlides, 'Contexto y Enfoque 3C')}
    </section>
  `;
};

/* ---------- 3. FLUJO DE COMPRA DE DIVISAS ---------- */
window.PresentationApp.Renderers.fxFlowSlide = function renderFxFlowSlide(slideNum, totalSlides) {
  const { fxFlow } = window.PresentationApp.CONTEXT;
  const { renderTopbar, renderFooter } = window.PresentationApp.UI;

  const stepShort = [
    { title: 'Apertura', key: 'Capital inicial · tasas del día' },
    { title: 'Cotización', key: 'Divisa + monto → USD en ≤ 1 s' },
    { title: 'Controles', key: 'Efectivo · alto monto · UAFE' },
    { title: 'Pago y registro', key: 'Solo USD efectivo · offline · nota de venta' },
    { title: 'Cierre', key: 'Gastos · consolidado · cuadre · reporte' }
  ];

  const rules = [
    { code: 'RN-01', text: 'Pago solo en USD efectivo' },
    { code: 'RN-02', text: 'Nueva tasa no altera compras previas' },
    { code: 'RNF-02/03', text: 'Opera sin Internet ≥ 4 h' },
    { code: 'RN-03', text: 'Datos personales solo sobre umbral UAFE' }
  ];

  return `
    <section class="slide" data-slide-title="Flujo de Compra de Divisas" data-slide-group="Dominio del Negocio">
      ${renderTopbar('Dominio · Compra de Divisas')}
      <div class="slide-body ov-body">
        <div class="eyebrow">Proceso de Negocio · Casa de Cambio</div>
        <h2 class="slide-heading">Una jornada en ventanilla: 08:30 → cierre</h2>

        <div class="ov-flow">
          ${fxFlow.steps.map((st, i) => `
            <div class="ov-step ${st.accent ? 'is-accent' : ''}" title="${st.desc}">
              <div class="ov-step-num">${String(i + 1).padStart(2, '0')}</div>
              <div class="ov-step-title">${stepShort[i].title}</div>
              <div class="ov-step-key">${stepShort[i].key}</div>
              <div class="ov-step-hus">
                ${st.hus.map((id) => `<button type="button" class="trace-link" data-goto-story="${id}">${id}</button>`).join('')}
              </div>
            </div>
          `).join('')}
        </div>

        <div class="ov-flow-bottom">
          <div>
            <div class="ov-section-label">Divisas operadas → USD</div>
            <div class="ov-currencies">
              ${fxFlow.currencies.map((c) => `
                <div class="ov-cur ${c.freq.startsWith('Alta') ? 'is-main' : ''}" title="${c.name} · ${c.freq}">
                  <span class="ov-cur-code">${c.code}</span>
                  ${/[×÷]/.test(c.op)
                    ? `<span class="ov-cur-op">${c.op.includes('×') ? '×' : '÷'}</span>`
                    : `<span class="ov-cur-op is-text">según tasa</span>`}
                </div>
              `).join('')}
            </div>
            <div class="ov-cur-legend"><span class="dot-main"></span> Alta frecuencia &nbsp; <span class="dot-minor"></span> Menor frecuencia</div>
          </div>
          <div>
            <div class="ov-section-label">Reglas clave</div>
            <div class="ov-rules">
              ${rules.map((r) => `
                <div class="ov-rule"><span class="ov-rule-code">${r.code}</span><span>${r.text}</span></div>
              `).join('')}
            </div>
          </div>
        </div>
      </div>
      ${renderFooter(slideNum, totalSlides, 'Flujo de Compra de Divisas')}
    </section>
  `;
};

/* ---------- 4. STAKEHOLDERS ---------- */
window.PresentationApp.Renderers.stakeholdersSlide = function renderStakeholdersSlide(slideNum, totalSlides) {
  const { CONFIG } = window.PresentationApp;
  const { renderTopbar, renderFooter } = window.PresentationApp.UI;

  const internal = [
    { name: 'Propietaria', tag: 'Decisora', key: 'Fija tasas · autoriza altos montos · recibe el reporte' },
    { name: 'Operadoras (incl. E1)', tag: 'Usuario final', key: 'Calculan · registran · cuadran la caja' },
    { name: 'Equipo IR · Grupo 6', tag: 'Desarrollo', key: 'Elicita · especifica 3C · traza con ENT-01' }
  ];
  const external = [
    { name: 'Clientes', tag: 'Beneficiario', key: 'Entregan divisa · reciben USD efectivo' },
    { name: 'UAFE + LOPDP', tag: 'Normativa', key: 'Umbral ref. USD 10.000 · mínimos datos' },
    { name: 'Cotización global', tag: 'Referencia', key: 'Apoya la tasa del día (P-09)' }
  ];

  const renderList = (items, badge) => items.map((s) => `
    <div class="ov-sh">
      <div class="ov-sh-head"><h4>${s.name}</h4><span class="badge ${badge}">${s.tag}</span></div>
      <p>${s.key}</p>
    </div>
  `).join('');

  return `
    <section class="slide" data-slide-title="Stakeholders Internos y Externos" data-slide-group="Introducción">
      ${renderTopbar('Actores y Partes Interesadas')}
      <div class="slide-body ov-body">
        <div class="eyebrow">Identificación de Roles</div>
        <h2 class="slide-heading">¿Quién participa?</h2>

        <div class="ov-po">
          <div class="ov-po-tag">Product Owner · Enlace con el negocio</div>
          <h3>${CONFIG.productOwner.name}</h3>
          <p>Valida cada necesidad y criterio · representa a la dueña (fuera del país) · <span>DEC-01-01</span></p>
        </div>

        <div class="ov-sh-grid">
          <div>
            <div class="ov-section-label">Internos</div>
            <div class="ov-sh-list">${renderList(internal, 'badge-neutral')}</div>
          </div>
          <div>
            <div class="ov-section-label">Externos</div>
            <div class="ov-sh-list">${renderList(external, 'badge-gold')}</div>
          </div>
        </div>
      </div>
      ${renderFooter(slideNum, totalSlides, 'Stakeholders y Roles')}
    </section>
  `;
};

/* ---------- 5. MAPA DE ÉPICAS ---------- */
window.PresentationApp.Renderers.epicsSlide = function renderEpicsSlide(slideNum, totalSlides) {
  const { STORIES } = window.PresentationApp;
  const { renderTopbar, renderFooter } = window.PresentationApp.UI;

  const groups = [
    { title: 'Gestión de Tasas', subtitle: 'Autorizar y consultar', items: STORIES.filter((s) => s.epic === 'Gestión de tasas') },
    { title: 'Atención de Compra', subtitle: 'Calcular, registrar, controlar', items: STORIES.filter((s) => s.epic === 'Atención de compra') },
    { title: 'Continuidad Operativa', subtitle: 'Sin Internet y recuperación', items: STORIES.filter((s) => s.epic === 'Continuidad operativa') },
    { title: 'Caja, Cierre y UAFE', subtitle: 'Capital, gastos, cuadre, reporte', items: STORIES.filter((s) => s.epic === 'Caja y cierre' || s.epic === 'Cumplimiento normativo') }
  ];

  return `
    <section class="slide" data-slide-title="Mapa de Épicas (18 HUs)" data-slide-group="Introducción">
      ${renderTopbar('Catálogo Funcional')}
      <div class="slide-body ov-body">
        <div class="eyebrow">4 Épicas · 18 Historias</div>
        <h2 class="slide-heading">Mapa de Historias de Usuario</h2>

        <div class="ov-epics">
          ${groups.map((g, gi) => `
            <div class="ov-epic">
              <div class="ov-epic-head">
                <span class="ov-epic-num">${gi + 1}</span>
                <div>
                  <div class="ov-epic-title">${g.title}</div>
                  <div class="ov-epic-sub">${g.subtitle}</div>
                </div>
              </div>
              <div class="ov-epic-list">
                ${g.items.map((st) => `
                  <button type="button" class="ov-hu-btn" data-goto-story="${st.id}" title="${st.title} · ${st.role}">
                    <span class="ov-hu-id">${st.id}</span>
                    <span class="ov-hu-name">${st.title}</span>
                    <span class="badge badge-moscow-${st.moscow}">${st.moscow}</span>
                  </button>
                `).join('')}
              </div>
            </div>
          `).join('')}
        </div>
        <div class="ov-hint">Clic en una historia para ir a su diapositiva · M Debe · S Debería · C Podría · W No por ahora</div>
      </div>
      ${renderFooter(slideNum, totalSlides, 'Mapa de Épicas')}
    </section>
  `;
};

/* ---------- 24. TRAZABILIDAD ---------- */
window.PresentationApp.Renderers.traceabilitySlide = function renderTraceabilitySlide(slideNum, totalSlides) {
  const { CONTEXT } = window.PresentationApp;
  const { renderTopbar, renderFooter } = window.PresentationApp.UI;

  const rows = CONTEXT.traceability;
  const sections = [
    { label: 'Requisitos funcionales', items: rows.filter((r) => r.req.startsWith('RF-')) },
    { label: 'No funcionales (ISO 25010)', items: rows.filter((r) => r.req.startsWith('RNF-')) },
    { label: 'Restricción y reglas de negocio', items: rows.filter((r) => r.req.startsWith('RES-') || r.req.startsWith('RN-')) }
  ];

  const tile = (r) => `
    <div class="ov-tr">
      <span class="ov-tr-req">${r.req}</span>
      <span class="ov-tr-hus">
        ${r.hus
          ? r.hus.map((id) => `<button type="button" class="trace-link" data-goto-story="${id}">${id.replace('HU-', '')}</button>`).join('')
          : `<span class="ov-tr-all">Todas</span>`}
      </span>
    </div>
  `;

  return `
    <section class="slide" data-slide-title="Matriz de Trazabilidad ENT-01" data-slide-group="Cierre">
      ${renderTopbar('Trazabilidad de Requisitos')}
      <div class="slide-body ov-body">
        <div class="eyebrow">Cobertura 100 %</div>
        <h2 class="slide-heading">Trazabilidad: ENT-01 ↔ Historias de Usuario</h2>

        ${sections.map((s) => `
          <div class="ov-section-label">${s.label} <span class="ov-count">${s.items.length}</span></div>
          <div class="ov-tr-grid">${s.items.map(tile).join('')}</div>
        `).join('')}

        <div class="ov-note" title="${CONTEXT.traceNote}">
          <b>Nota:</b> tiempos y umbral USD 2.000 = propuestas a validar (P-03) · tasas de los criterios = datos de prueba
        </div>
      </div>
      ${renderFooter(slideNum, totalSlides, 'Matriz de Trazabilidad')}
    </section>
  `;
};

/* ---------- 25. CIERRE ---------- */
window.PresentationApp.Renderers.closingSlide = function renderClosingSlide() {
  const { institution, course, members, productOwner } = window.PresentationApp.CONFIG;

  return `
    <section class="slide slide-closing" data-slide-title="Cierre y Preguntas" data-slide-group="Cierre">
      <div class="closing-content">
        <div class="closing-logo-badge">
          <img src="${institution.logoHorizontal}" alt="Logotipo oficial ${institution.shortName}" />
        </div>
        <div class="closing-eyebrow">${institution.career}</div>
        <h2 class="closing-title">Muchas Gracias</h2>
        <p class="closing-desc">¿Preguntas?</p>

        <div class="closing-stats">
          <div class="closing-stat"><strong>18</strong><span>Historias de Usuario</span></div>
          <div class="closing-stat"><strong>100%</strong><span>Cobertura RF-01…RF-20</span></div>
          <div class="closing-stat"><strong>3C</strong><span>Tarjeta · Conversación · Confirmación</span></div>
          <div class="closing-stat"><strong>NRC ${course.nrc}</strong><span>${course.group}</span></div>
        </div>

        <div class="closing-meta">
          <strong>Integrantes:</strong> ${members.join(' · ')}<br/>
          <strong>Product Owner:</strong> ${productOwner.name}
        </div>
      </div>
    </section>
  `;
};
