/**
 * ============================================================================
 * RENDERIZADOR: ANEXOS DE EVIDENCIAS
 * Galería "justificada": todas las imágenes de una fila tienen la misma altura
 * y su ancho se calcula con su proporción real → nunca se ven deformadas.
 * Clic en una imagen = ampliar (ver js/lightbox.js).
 * ============================================================================
 */
window.PresentationApp = window.PresentationApp || {};
window.PresentationApp.Renderers = window.PresentationApp.Renderers || {};

window.PresentationApp.Renderers.annexSlide = function renderAnnexSlide(annex, slideNum, totalSlides) {
  const { renderTopbar, renderFooter, escapeHtml: esc } = window.PresentationApp.UI;

  // Espacio útil de la galería dentro del lienzo 1280×720
  const AVAIL_W = 1192;          // 1280 − 2 × 44 px de margen
  const AVAIL_H = 470;           // alto total para imágenes (sin leyendas)
  const GAP = 18;
  const rowMaxH = AVAIL_H / annex.rows.length;

  const rowsHtml = annex.rows.map((row) => {
    const ratioSum = row.reduce((acc, img) => acc + img.w / img.h, 0);
    const h = Math.floor(Math.min(rowMaxH, (AVAIL_W - GAP * (row.length - 1)) / ratioSum));

    return `
      <div class="ax-row" style="gap:${GAP}px;">
        ${row.map((img) => {
          const w = Math.floor(h * (img.w / img.h));
          return `
            <figure class="ax-fig" style="width:${w}px;">
              <button type="button" class="ax-frame" style="height:${h}px;" data-lightbox="${img.src}" data-caption="${esc(img.caption)} · ${esc(img.sub)}">
                <img src="${img.src}" alt="${esc(img.caption)}" loading="lazy" />
                ${img.tag ? `<span class="ax-tag">${esc(img.tag)}</span>` : ''}
                <span class="ax-zoom" aria-hidden="true">⤢</span>
              </button>
              <figcaption>
                <b>${esc(img.caption)}</b>
                <span>${esc(img.sub)}</span>
              </figcaption>
            </figure>
          `;
        }).join('')}
      </div>
    `;
  }).join('');

  return `
    <section class="slide ax-slide" data-slide-title="Anexo ${annex.code}: ${esc(annex.title)}" data-slide-group="Anexos · Evidencias">
      ${renderTopbar(`Anexo ${annex.code} · Evidencias`)}
      <div class="slide-body ax-body">
        <div class="ax-head">
          <div>
            <div class="eyebrow">Anexo ${annex.code} · ${esc(annex.group)}</div>
            <h2 class="slide-heading">${esc(annex.title)}</h2>
          </div>
          <div class="ax-hus">
            <span>Respalda</span>
            ${annex.hus.map((id) => `<button type="button" class="trace-link" data-goto-story="${id}">${id}</button>`).join('')}
          </div>
        </div>
        <div class="ax-gallery">${rowsHtml}</div>
      </div>
      ${renderFooter(slideNum, totalSlides, `Anexo ${annex.code}`)}
    </section>
  `;
};
