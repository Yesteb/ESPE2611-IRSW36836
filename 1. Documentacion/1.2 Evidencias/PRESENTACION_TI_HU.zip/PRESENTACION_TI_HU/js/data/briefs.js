/**
 * ============================================================================
 * SÍNTESIS VISUAL DE LAS 18 HISTORIAS DE USUARIO
 * Versión condensada (ideas y palabras clave) que se muestra en pantalla.
 * El texto completo sigue en stories.js y aparece como tooltip al pasar el mouse.
 *
 *  quiero / para : enunciado corto de la tarjeta (1C)
 *  rules  : [palabra clave, idea]                       (2C)
 *  ca     : [nombre, dado, cuando, entonces]            (3C · Gherkin)
 *  rnf    : [atributo ISO 25010, métrica]
 *  ui     : pantalla principal
 * ============================================================================
 */
window.PresentationApp = window.PresentationApp || {};

window.PresentationApp.BRIEFS = {
  'HU-01': {
    quiero: 'registrar cada mañana la tasa de cada divisa y su sentido (× / ÷)',
    para: 'que solo se apliquen tasas autorizadas',
    rules: [
      ['Autoridad', 'Solo la propietaria fija tasas; revisión diaria'],
      ['Sentido fijo', 'Cada divisa multiplica o divide'],
      ['Inmutable', 'Compras previas conservan su tasa'],
      ['Divisas', 'EUR · COP · PEN (+ BRL, GBP, CLP) · catálogo P-11'],
      ['Permisos', 'Ingreso en ausencia de la dueña → P-04']
    ],
    ca: [
      ['Registro', 'EUR sin tasa hoy', 'registra 1,08 ×', 'visible en 2 ventanillas ≤ 5 s'],
      ['Cambio intradía', '3 compras a 1,08', 'nueva tasa 1,06', 'nuevas 1,06 · previas 1,08'],
      ['Dato inválido', 'registrando tasa', '0, negativo o sin sentido', 'no guarda · marca error'],
      ['Bitácora', 'tasa 1,08', 'cambia a 1,06', 'log inalterable (usuario, hora, antes/después)']
    ],
    rnf: [['No repudio', 'RNF-06 · 100 % en bitácora inalterable'], ['Corrección', '≤ 5 s en ambas ventanillas']],
    ui: 'Tasas del día'
  },
  'HU-02': {
    quiero: 'ver la cotización global junto a la tasa vigente',
    para: 'decidir la tasa sin buscar en otra web',
    rules: [
      ['Solo referencia', 'Nunca se aplica a una compra'],
      ['Fuente externa', 'Definida en P-09 · riesgo técnico alto'],
      ['Sin Internet', 'Última cotización + fecha-hora']
    ],
    ca: [
      ['Con conexión', 'fuente P-09 configurada', 'abre “Tasas del día”', 'cotización + fecha-hora ≤ 10 s'],
      ['Sin conexión', 'sin Internet', 'abre “Tasas del día”', 'última cotización + aviso'],
      ['No se aplica', 'global 1,10 · vigente 1,08', 'calcula compra EUR', 'aplica 1,08']
    ],
    rnf: [['Interoperabilidad', '≥ 95 % consultas exitosas'], ['Desempeño', '≤ 10 s con conexión']],
    ui: 'Columna “Cotización global”'
  },
  'HU-03': {
    quiero: 'ingresar divisa y monto y ver al instante los USD a pagar',
    para: 'atender sin cálculos manuales ni errores',
    rules: [
      ['Fórmula', 'Tasa vigente × o ÷ según la divisa'],
      ['Antes de confirmar', 'Resultado visible para el cliente'],
      ['Redondeo', '2 decimales · regla en P-11'],
      ['Datos de prueba', 'Las tasas de los CA no son reales']
    ],
    ca: [
      ['Multiplica', 'EUR a 1,08 ×', 'ingresa EUR 250', 'USD 270,00 ≤ 1 s'],
      ['Divide', 'COP a 4.100 ÷', 'ingresa COP 400.000', 'USD 97,56 ≤ 1 s'],
      ['Sin tasa', 'BRL sin tasa hoy', 'selecciona BRL', 'no calcula · aviso'],
      ['Monto inválido', 'EUR seleccionado', 'ingresa 0 o negativo', 'no calcula · error']
    ],
    rnf: [['Corrección', 'RNF-05 · error ≤ USD 0,01'], ['Tiempo', 'RNF-01a · p95 ≤ 1 s']],
    ui: 'Nueva compra'
  },
  'HU-04': {
    quiero: 'confirmar la compra y que se registre automáticamente',
    para: 'dejar de anotar en el cuaderno',
    rules: [
      ['Pago', 'Solo USD en efectivo (RN-01)'],
      ['Registro', 'Divisa, monto, tasa, USD, hora, ventanilla, usuario'],
      ['Privacidad', 'Sin datos del cliente (excepción HU-18)'],
      ['Concurrencia', '2 ventanillas a la vez'],
      ['Atención', '≤ 5 min por cliente']
    ],
    ca: [
      ['Registro exitoso', 'EUR 250 = USD 270', 'confirma', 'guardado + N.º operación ≤ 2 s'],
      ['Dos ventanillas', 'confirman al mismo tiempo', 'se guardan', '2 compras · sin duplicados'],
      ['Cliente desiste', 'no acepta el cálculo', 'cancela', 'sin registro ni cambio de caja'],
      ['Tiempo', '≤ 30 min de capacitación', 'registra 20 compras', 'p90 ≤ 2 min']
    ],
    rnf: [['Operabilidad', 'RNF-01b · p90 ≤ 2 min'], ['Integridad', 'RNF-03 · 0 pérdidas o duplicados']],
    ui: 'Confirmación en “Nueva compra”'
  },
  'HU-05': {
    quiero: 'ver el efectivo USD disponible y ser advertida si no alcanza',
    para: 'no comprometer un pago imposible',
    rules: [
      ['Fórmula', 'Capital + ingresos − pagos − gastos'],
      ['Si no alcanza', 'Avisar a la dueña: esperar 30–40 min o pago parcial'],
      ['Solo aviso', 'Informa, no bloquea la compra'],
      ['Fondo único', 'Compartido por las 2 ventanillas (P-12)']
    ],
    ca: [
      ['Saldo actualizado', 'capital USD 5.000', 'compra USD 270', 'saldo USD 4.730 ≤ 2 s'],
      ['Insuficiente', 'saldo USD 300', 'calcula USD 450', '“Faltan USD 150”'],
      ['Suficiente', 'saldo USD 300', 'calcula USD 250', 'sin advertencia']
    ],
    rnf: [['Corrección', 'Exacto al centavo (20 pruebas)'], ['Tiempo', 'Saldo actualizado ≤ 2 s']],
    ui: 'Indicador “Efectivo disponible”'
  },
  'HU-06': {
    quiero: 'registrar la autorización de un alto monto o tasa especial',
    para: 'dejar constancia de quién aprobó',
    rules: [
      ['Umbral', 'Montos altos → autoriza la propietaria'],
      ['Configurable', 'Valor exacto se acuerda en P-01'],
      ['Prueba', 'Umbral referencial USD 2.000'],
      ['Evidencia', 'Medio (llamada, mensaje) en P-01']
    ],
    ca: [
      ['Sobre umbral', 'umbral USD 2.000', 'calcula USD 2.500', 'pide autorización antes de confirmar'],
      ['Autorizada', 'se pidió autorización', 'registra quién, cuándo, medio', 'habilita “Confirmar”'],
      ['Tasa especial', 'vigente 1,08', 'aplica 1,09', 'exige autorización'],
      ['Monto ordinario', 'umbral USD 2.000', 'calcula USD 1.500', 'no pide autorización']
    ],
    rnf: [['Responsabilidad', '100 % autorizadas · 0 omisiones'], ['Operabilidad', 'Registro ≤ 1 min']],
    ui: 'Ventana “Autorización”'
  },
  'HU-07': {
    quiero: 'imprimir la nota de venta cuando el cliente la pida',
    para: 'entregar comprobante sin escribir a mano',
    rules: [
      ['A pedido', 'Solo si el cliente la solicita'],
      ['Contenido', 'Divisa, monto, tasa, USD, fecha, firma y sello'],
      ['Sin datos personales', 'Campos legales mínimos en P-07']
    ],
    ca: [
      ['Emisión', 'compra EUR 250 → USD 270', 'solicita la nota', 'nota imprimible ≤ 5 s'],
      ['Sin confirmar', 'compra no confirmada', 'intenta emitir', 'bloquea · aviso'],
      ['Reimpresión', 'nota ya emitida', 'la pide otra vez', 'misma nota marcada “Copia”']
    ],
    rnf: [['Corrección', '100 % coincide con la compra'], ['Tiempo', 'Generación ≤ 5 s']],
    ui: 'Botón “Nota de venta”'
  },
  'HU-08': {
    quiero: 'corregir una compra indicando el motivo y conservando el original',
    para: 'cuadrar sin perder la evidencia',
    rules: [
      ['Situación actual', 'Sin anulación: asume quien atendió'],
      ['Versionado', 'Nunca borra: crea nueva versión'],
      ['Permisos', 'Quién y hasta cuándo → P-04'],
      ['Prioridad C', 'No priorizada inicialmente por E1']
    ],
    ca: [
      ['Con motivo', 'EUR 250 a 1,08', 'corrige a EUR 200 + motivo', 'USD 216 · guarda versiones · ajusta caja'],
      ['Sin motivo', 'corrigiendo', 'guarda sin motivo', 'bloquea · motivo obligatorio'],
      ['Historial', 'compra corregida', 'la propietaria consulta', 'original, nuevo, motivo, usuario, hora']
    ],
    rnf: [['No repudio', 'RNF-06 · 100 % trazado · 0 alterables']],
    ui: 'Acción “Corregir” + historial'
  },
  'HU-09': {
    quiero: 'buscar compras por fecha y por divisa',
    para: 'revisar operaciones sin leer todo el día',
    rules: [
      ['Filtros', 'Fecha y divisa (propuesta a validar en P-03)'],
      ['Sin cliente', 'No hay datos personales para buscar']
    ],
    ca: [
      ['Con filtros', '120 compras (1–15 dic)', 'filtra EUR del 10/12', 'lista + totales ≤ 3 s'],
      ['Sin resultados', 'sin GBP ese día', 'aplica el filtro', '“No hay compras con esos filtros”'],
      ['Rango inválido', 'filtrando por fechas', 'inicio posterior al fin', 'no busca · error']
    ],
    rnf: [['Tiempo', 'p95 ≤ 3 s con 10.000 compras']],
    ui: 'Pantalla “Compras”'
  },
  'HU-10': {
    quiero: 'seguir calculando y registrando compras sin Internet',
    para: 'no detener la atención ni volver al cálculo manual',
    rules: [
      ['Problema N.º 1', 'Caídas de Internet (DEC-01-23)'],
      ['Tasa local', 'Última autorizada + fecha-hora'],
      ['Tasa antigua', 'Confirmar y marcar para revisión'],
      ['Sincronización', 'Sin pérdidas ni duplicados'],
      ['Cierre', 'Hora formal en P-05']
    ],
    ca: [
      ['Sin conexión', 'offline · EUR 1,08 guardado', 'ingresa EUR 100', 'USD 108 + “Sin conexión”'],
      ['Tasa de ayer', 'offline · tasa de ayer', 'calcula', 'pide confirmar · marca revisión'],
      ['Sincroniza', '20 compras offline', 'vuelve Internet', '100 % en ≤ 5 min'],
      ['Jornada offline', 'sin red desde la apertura', 'pasan 4 h', 'opera con normalidad']
    ],
    rnf: [['Tolerancia a fallos', 'RNF-02 · ≥ 4 h offline · sync ≤ 5 min'], ['Integridad', 'RNF-03 · 0 pérdidas o duplicados']],
    ui: 'Indicador de conexión + pendientes'
  },
  'HU-11': {
    quiero: 'recuperar la compra en curso tras un corte o cierre inesperado',
    para: 'terminarla sin volver a pedir datos al cliente',
    rules: [
      ['Clave', 'Recuperar la cotización aplicada'],
      ['Alcance', 'Solo compras no confirmadas'],
      ['Decisión', 'La operadora continúa o descarta'],
      ['Tasa cambió', 'Regla de precedencia en P-01']
    ],
    ca: [
      ['Recuperación', 'EUR 250 a 1,08 en curso', 'cierre inesperado', 'datos visibles ≤ 1 min'],
      ['Descartar', 'compra recuperada', 'elige descartar', 'no registra nada'],
      ['Tasa cambió', 'la tasa pasó a 1,06', 'retoma la compra', 'muestra ambas · debe elegir']
    ],
    rnf: [['Recuperación', 'RNF-04 · 100 % en ≤ 1 min']],
    ui: 'Aviso “Compra pendiente”'
  },
  'HU-12': {
    quiero: 'registrar al abrir el efectivo USD entregado por la propietaria',
    para: 'controlar pagos y cuadrar al cierre',
    rules: [
      ['Base del cuadre', 'Capital entregado por la propietaria'],
      ['Uno por jornada', 'Cualquier cambio exige motivo'],
      ['Horario', 'Atención desde las 08:30']
    ],
    ca: [
      ['Registro', 'sin capital hoy', 'registra USD 5.000', 'guardado · efectivo disponible'],
      ['Sin capital', 'jornada sin capital', 'intenta confirmar compra', 'pide registrar capital'],
      ['Inválido', 'registrando capital', '0 o negativo', 'no guarda · error']
    ],
    rnf: [['Operabilidad', '≤ 1 min sin asistencia'], ['Responsabilidad', '100 % de cambios con motivo']],
    ui: 'Apertura de jornada'
  },
  'HU-13': {
    quiero: 'registrar el efectivo adicional que envía la propietaria',
    para: 'que saldo y cuadre lo incluyan',
    rules: [
      ['Reposición', 'La gestiona la propietaria · 30–40 min'],
      ['Registro', 'Monto USD, hora y quién entrega']
    ],
    ca: [
      ['Ingreso', 'saldo USD 300', 'ingresa USD 1.000', 'saldo USD 1.300 ≤ 2 s'],
      ['Inválido', 'registrando ingreso', '0 o negativo', 'no guarda · error'],
      ['En el cuadre', 'ingreso USD 1.000', 'calcula el cuadre', 'se suma al capital']
    ],
    rnf: [['Corrección', '100 % reflejado sin diferencias']],
    ui: 'Acción “Ingreso de efectivo”'
  },
  'HU-14': {
    quiero: 'registrar cada gasto pagado con la caja',
    para: 'que reporte y cuadre lo incluyan',
    rules: [
      ['Reporte', 'Gastos si existieron; si no, solo divisas y efectivo'],
      ['Registro', 'Valor USD, descripción, hora, usuario'],
      ['Descripción libre', 'Categorías por validar en P-03']
    ],
    ca: [
      ['Registro', 'saldo USD 1.000', 'gasto USD 12,50 “útiles”', 'saldo USD 987,50'],
      ['Incompleto', 'registrando gasto', 'sin descripción o ≤ 0', 'no guarda · error'],
      ['Sin gastos', 'día sin gastos', 'genera reporte', 'gastos = USD 0,00']
    ],
    rnf: [['Operabilidad', '≤ 1 min sin asistencia']],
    ui: 'Acción “Gasto”'
  },
  'HU-15': {
    quiero: 'ver al cierre los totales por divisa y tasa con su valor en USD',
    para: 'dejar de sumar a mano',
    rules: [
      ['Cierre', 'Totaliza divisas, tasas y efectivo'],
      ['Por tasa', 'Subtotal por cada tasa del día'],
      ['Cobertura', '2 ventanillas + compras offline sincronizadas']
    ],
    ca: [
      ['Por tasa', 'EUR 250 a 1,08 · EUR 200 a 1,06', 'abre consolidado', 'USD 270 + 212 = USD 482'],
      ['Pendientes', '2 compras sin sincronizar', 'abre consolidado', 'aviso · impide cerrar'],
      ['Exactitud', '50 compras de prueba', 'compara con referencia', 'diferencia USD 0,00']
    ],
    rnf: [['Corrección', 'Exacto al centavo'], ['Tiempo', '≤ 3 s con 300 compras']],
    ui: 'Cierre – consolidado'
  },
  'HU-16': {
    quiero: 'comparar el capital con efectivo restante, pagos y gastos',
    para: 'saber si la caja cuadra antes de reportar',
    rules: [
      ['Fórmula', 'Contado + pagos + gastos − capital − ingresos'],
      ['Conteo físico', 'La operadora ingresa el efectivo contado'],
      ['Diferencia ≠ 0', 'Exige observación antes de cerrar'],
      ['Revisión', 'Lista compras con tasa de otro día']
    ],
    ca: [
      ['Cuadrada', 'capital 5.000 · compras 482 · gastos 12,50', 'cuenta USD 4.505,50', 'diferencia 0 · “Cuadrada”'],
      ['Faltante', 'mismo escenario', 'cuenta USD 4.495,50', '“Faltante USD 10” · pide observación'],
      ['Revisión', '1 compra con tasa antigua', 'abre el cuadre', 'destacada “Para revisión”']
    ],
    rnf: [['Corrección', 'Exacto al centavo (20 escenarios)'], ['Operabilidad', 'Cuadre ≤ 5 min']],
    ui: 'Cierre – cuadre'
  },
  'HU-17': {
    quiero: 'recibir un reporte diario de divisas, efectivo, gastos y cuadre',
    para: 'controlar el negocio a distancia',
    rules: [
      ['Contexto', 'La propietaria reside fuera del país'],
      ['Contenido', 'Divisas, efectivo, gastos y cuadre'],
      ['Canal', 'Correo o descarga (P-03)'],
      ['Privacidad', 'Sin datos de clientes']
    ],
    ca: [
      ['Generación', 'jornada cuadrada', 'cierra la jornada', 'reporte ≤ 10 s'],
      ['Envío', 'reporte listo + conexión', 'lo envía', 'recibido · hora registrada'],
      ['Sin conexión', 'offline al cierre', 'intenta enviar', 'en cola · envío automático']
    ],
    rnf: [['Corrección', '100 % igual a consolidado y cuadre'], ['Tolerancia a fallos', 'Cola enviada ≤ 5 min']],
    ui: '“Cerrar jornada y enviar reporte”'
  },
  'HU-18': {
    quiero: 'pedir identificación del cliente solo sobre el umbral UAFE',
    para: 'cumplir la norma sin demorar compras ordinarias',
    rules: [
      ['Situación actual', 'No se piden datos del cliente'],
      ['Ley 2024', 'Sujetos UAFE · ref. USD 10.000 (P-02)'],
      ['LOPDP', 'Bajo umbral: cero datos personales'],
      ['Prioridad W', 'Sube a M si P-02 confirma la obligación']
    ],
    ca: [
      ['Sobre umbral', 'umbral USD 10.000', 'calcula USD 10.500', 'exige documento del cliente'],
      ['Ordinaria', 'umbral USD 10.000', 'calcula USD 800', 'sin datos personales'],
      ['Acceso restringido', 'compra con identificación', 'usuario sin permiso consulta', 'oculta el documento']
    ],
    rnf: [['Confidencialidad', '0 datos bajo umbral · acceso por rol']],
    ui: 'Campos condicionales de documento'
  }
};
