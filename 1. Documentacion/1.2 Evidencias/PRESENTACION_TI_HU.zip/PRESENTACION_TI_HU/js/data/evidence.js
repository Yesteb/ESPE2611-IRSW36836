/**
 * ============================================================================
 * ANEXOS · EVIDENCIAS DEL PROCESO ACTUAL (carpeta "Evidencias" del Drive del grupo)
 * Cada imagen declara su tamaño real (w × h) para mostrarla SIEMPRE en su
 * proporción original (sin estirar ni recortar).
 *
 *  rows : filas de la galería; todas las imágenes de una fila comparten altura.
 *  tag  : etiqueta opcional sobre la imagen (p. ej. "Editada").
 * ============================================================================
 */
window.PresentationApp = window.PresentationApp || {};

window.PresentationApp.EVIDENCE = [
  {
    code: 'A',
    title: 'Tasas del día: en papel y por WhatsApp',
    group: 'Tasas y cotizaciones',
    hus: ['HU-01', 'HU-02', 'HU-03'],
    rows: [[
      { src: 'assets/anexos/tablero-tasas.png', w: 899, h: 1599, caption: 'Tablero de tasas en ventanilla', sub: 'Compra / venta · × ÷ por divisa' },
      { src: 'assets/anexos/cotizacion-hoja.png', w: 1053, h: 1594, caption: 'Cotización escrita a mano', sub: 'EUR 1,10 · COP 3316' },
      { src: 'assets/anexos/whatsapp-cotizacion-08-11.png', w: 1192, h: 697, caption: 'Cotización enviada por WhatsApp', sub: '08/11/2026 · EUR 1,11 · COP 3246' }
    ]]
  },
  {
    code: 'B',
    title: 'Cierres de caja en hojas físicas',
    group: 'Cierres en papel',
    hus: ['HU-12', 'HU-15', 'HU-16'],
    rows: [[
      { src: 'assets/anexos/cierre-27-09.png', w: 898, h: 1217, caption: '27/09/2026', sub: 'Cuadre sobre $1000' },
      { src: 'assets/anexos/cierre-31-10.png', w: 920, h: 1280, caption: '31/10/2026', sub: 'EUR · BRL · efectivo' },
      { src: 'assets/anexos/cierre-01-11.png', w: 942, h: 1279, caption: '01/11/2026', sub: 'EUR · BRL · COP · efectivo' },
      { src: 'assets/anexos/cierre-sin-fecha.png', w: 1280, h: 894, caption: 'Sin fecha', sub: 'EUR · COP · efectivo' }
    ]]
  },
  {
    code: 'C',
    title: 'Reporte diario enviado por WhatsApp (1/2)',
    group: 'Reportes de cierre',
    hus: ['HU-13', 'HU-16', 'HU-17'],
    rows: [[
      { src: 'assets/anexos/whatsapp-reporte-07-11.png', w: 1158, h: 562, caption: '07/11/2026', sub: 'Bóveda + préstamo · total $6500' },
      { src: 'assets/anexos/whatsapp-reporte-08-11.png', w: 655, h: 388, caption: '08/11/2026', sub: 'Redondeo manual “+0,03” en COP' }
    ]]
  },
  {
    code: 'D',
    title: 'Reporte diario enviado por WhatsApp (2/2)',
    group: 'Reportes de cierre',
    hus: ['HU-16', 'HU-17', 'HU-01'],
    rows: [[
      { src: 'assets/anexos/whatsapp-reporte-14-11.jpg', w: 3172, h: 1344, caption: '14/11/2026', sub: 'Total $6500,04 → sobrante $0,04', tag: 'Editada' },
      { src: 'assets/anexos/whatsapp-cotizacion-reporte-15-11.png', w: 1220, h: 917, caption: '15/11/2026', sub: 'Reporte + cotización del día siguiente' }
    ]]
  },
  {
    code: 'E',
    title: 'Atención en ventanilla',
    group: 'Contexto operativo',
    hus: ['HU-03', 'HU-04'],
    rows: [[
      { src: 'assets/anexos/ventanilla-atencion.jpg', w: 2730, h: 1536, caption: 'Cliente entrega euros en ventanilla', sub: 'Pago en USD efectivo' }
    ]]
  }
];
