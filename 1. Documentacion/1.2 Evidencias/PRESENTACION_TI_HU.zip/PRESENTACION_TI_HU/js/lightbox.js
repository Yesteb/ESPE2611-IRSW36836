/**
 * ============================================================================
 * VISOR AMPLIADO DE EVIDENCIAS (lightbox)
 * Clic en una imagen de anexo → se abre a pantalla completa en su proporción real.
 * Esc, clic fuera o el botón × lo cierran. Mientras está abierto, las flechas
 * no cambian de diapositiva.
 * ============================================================================
 */
(function initLightbox() {
  const box = document.createElement('div');
  box.className = 'lightbox';
  box.innerHTML = `
    <button type="button" class="lightbox-close" aria-label="Cerrar imagen">×</button>
    <img class="lightbox-img" alt="" />
    <div class="lightbox-caption"></div>
  `;
  document.body.appendChild(box);

  const imgEl = box.querySelector('.lightbox-img');
  const capEl = box.querySelector('.lightbox-caption');

  function open(src, caption) {
    imgEl.src = src;
    imgEl.alt = caption || '';
    capEl.textContent = caption || '';
    box.classList.add('is-open');
  }

  function close() {
    box.classList.remove('is-open');
  }

  document.addEventListener('click', (e) => {
    const trigger = e.target.closest('[data-lightbox]');
    if (trigger) {
      open(trigger.getAttribute('data-lightbox'), trigger.getAttribute('data-caption'));
      return;
    }
    if (box.classList.contains('is-open') && (e.target === box || e.target.closest('.lightbox-close'))) {
      close();
    }
  });

  // Fase de captura: se ejecuta antes que la navegación del deck
  document.addEventListener('keydown', (e) => {
    if (!box.classList.contains('is-open')) return;
    e.stopPropagation();
    e.preventDefault();
    if (e.key === 'Escape' || e.key === ' ' || e.key === 'Enter') close();
  }, true);
})();
