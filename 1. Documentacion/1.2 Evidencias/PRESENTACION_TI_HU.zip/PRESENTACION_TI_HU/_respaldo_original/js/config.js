/**
 * ============================================================================
 * CONFIGURACIÓN INSTITUCIONAL DE LA PRESENTACIÓN
 * Edita este archivo para actualizar logos, nombres, NRC, fecha o títulos.
 * ============================================================================
 */
window.PresentationApp = window.PresentationApp || {};

window.PresentationApp.CONFIG = {
  institution: {
    name: 'Universidad de las Fuerzas Armadas – ESPE',
    shortName: 'ESPE',
    motto: 'Innovación para la Excelencia',
    department: 'Departamento de Ciencias de la Computación',
    career: 'Carrera de Ingeniería de Software',
    // Sellos oficiales ESPE integrados en assets/
    logoShield: 'assets/espe-escudo.png',
    logoHorizontal: 'assets/espe-logo-horizontal.png'
  },
  course: {
    subject: 'Ingeniería de Requisitos de Software',
    nrc: '36836',
    group: 'Grupo N.º 6',
    date: '22/11/2026'
  },
  presentation: {
    techniqueTag: 'Técnicas de Elicitación · Historias de Usuario',
    titleMain: 'Sistema de Compra',
    titleHighlight: 'de Divisas',
    subtitle: 'Especificación ágil de requisitos bajo el enfoque 3C (Tarjeta, Conversación y Confirmación), derivada de la entrevista ENT-01 (v1.1 validada por E1).'
  },
  members: [
    'Gallardo',
    'Julio Sánchez',
    'José Villa'
  ],
  productOwner: {
    name: 'Leticia Lucia Guano García (E1)',
    role: 'Product Owner / Enlace directo con el negocio',
    note: 'Actúa como representante del cliente mientras la propietaria se encuentra fuera del país (DEC-01-01).'
  },
  moscowLabels: {
    M: 'M · Debe tener',
    S: 'S · Debería',
    C: 'C · Podría',
    W: 'W · No por ahora'
  }
};
