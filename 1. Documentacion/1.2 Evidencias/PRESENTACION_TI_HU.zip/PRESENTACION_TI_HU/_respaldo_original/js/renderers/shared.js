/**
 * ============================================================================
 * UTILIDADES COMPARTIDAS DE RENDERIZADO
 * ============================================================================
 */
window.PresentationApp = window.PresentationApp || {};

window.PresentationApp.UI = {
  escapeHtml(str) {
    return String(str ?? '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  },

  renderTopbar(sectionLabel) {
    const { institution, course } = window.PresentationApp.CONFIG;
    return `
      <header class="slide-topbar">
        <div class="topbar-brand">
          <img src="${institution.logoHorizontal}" alt="Logotipo oficial ${institution.shortName}" />
          <span class="topbar-sep"></span>
          <span>${institution.career}</span>
        </div>
        <div class="topbar-meta">
          <span>${sectionLabel}</span>
          <span class="dot"></span>
          <span>NRC ${course.nrc}</span>
        </div>
      </header>
    `;
  },

  renderFooter(slideNumber, totalSlides, rightLabel) {
    const { course, presentation } = window.PresentationApp.CONFIG;
    const padded = String(slideNumber).padStart(2, '0');
    const paddedTotal = String(totalSlides).padStart(2, '0');
    return `
      <footer class="slide-footer">
        <span><strong>${course.subject}</strong> · ${presentation.titleMain} ${presentation.titleHighlight}</span>
        <span>${rightLabel ? `${rightLabel} · ` : ''}${course.group} · Diapositiva <strong>${padded} / ${paddedTotal}</strong></span>
      </footer>
    `;
  }
};
