/**
 * ============================================================================
 * RENDERIZADOR MODULAR: DIAPOSITIVA DE HISTORIA DE USUARIO (HU-01..HU-18)
 * Muestra 3C (Tarjeta, Conversación, Confirmación Gherkin), RNF, UI e INVEST.
 * Sin ninguna mención a Sprints.
 * ============================================================================
 */
window.PresentationApp = window.PresentationApp || {};
window.PresentationApp.Renderers = window.PresentationApp.Renderers || {};

window.PresentationApp.Renderers.storySlide = function renderStorySlide(story, slideNum, totalSlides) {
  const { CONFIG, UI } = window.PresentationApp;
  const { escapeHtml, renderTopbar, renderFooter } = UI;

  const investKeys = [
    { key: 'I', label: 'Independiente' },
    { key: 'N', label: 'Negociable' },
    { key: 'V', label: 'Valiosa' },
    { key: 'E', label: 'Estimable' },
    { key: 'S', label: 'Acotada (Small)' },
    { key: 'T', label: 'Verificable' }
  ];

  const moscowText = CONFIG.moscowLabels[story.moscow] || story.moscow;

  return `
    <section
      class="slide"
      data-story-id="${story.id}"
      data-slide-title="${story.id}: ${escapeHtml(story.title)}"
      data-slide-group="${escapeHtml(story.epic)}"
    >
      ${renderTopbar(`Historia de Usuario · ${story.epic}`)}

      <div class="slide-body">
        <!-- Cabecera de la Historia -->
        <div class="story-header">
          <div class="story-id-group">
            <div class="story-id-pill">${story.id}</div>
            <div>
              <div class="story-epic-label">Épica: ${escapeHtml(story.epic)}</div>
              <h2 class="story-title">${escapeHtml(story.title)}</h2>
            </div>
          </div>

          <div class="story-badges">
            <span class="badge badge-moscow-${story.moscow}">${moscowText}</span>
            <span class="badge badge-neutral">${story.points} pts</span>
            <span class="badge badge-neutral">Valor: ${story.businessValue}</span>
            <span class="badge badge-risk-${story.techRisk}">Riesgo: ${story.techRisk}</span>
          </div>
        </div>

        <!-- 1C: Tarjeta (Como / Quiero / Para) + Metadatos de identificación -->
        <div class="story-card-banner">
          <div class="story-statement">
            <div class="story-line"><strong>Como</strong> ${escapeHtml(story.card.como)}</div>
            <div class="story-line"><strong>Quiero</strong> ${escapeHtml(story.card.quiero)}</div>
            <div class="story-line"><strong>Para</strong> ${escapeHtml(story.card.para)}</div>
          </div>

          <div class="story-meta-box">
            <div class="story-meta-row">
              <span>Rol / Actor:</span>
              <span>${escapeHtml(story.role)}</span>
            </div>
            <div class="story-meta-row">
              <span>Product Owner:</span>
              <span>${escapeHtml(CONFIG.productOwner.name)}</span>
            </div>
            <div class="story-meta-row">
              <span>Depende de:</span>
              <span>${escapeHtml(story.dependsOn)}</span>
            </div>
            <div class="story-meta-row">
              <span>Fuente:</span>
              <span>${escapeHtml(story.source)}</span>
            </div>
          </div>
        </div>

        <!-- Columnas 2C (Conversación + RNF) y 3C (Confirmación Gherkin + INVEST) -->
        <div class="story-columns">
          <!-- Columna Izquierda -->
          <div class="story-col">
            <div class="panel" style="flex:1; display:flex; flex-direction:column;">
              <div class="panel-title">
                <span>2C · Conversación y Reglas de Negocio</span>
                <span class="tag-count">${story.rules.length} reglas</span>
              </div>
              <ul class="rules-list">
                ${story.rules.map((r) => `
                  <li>
                    <span class="rule-code">${r.id}</span>
                    <span>${escapeHtml(r.text)}</span>
                  </li>
                `).join('')}
              </ul>
            </div>

            <div class="panel" style="display:flex; flex-direction:column; gap:8px;">
              <div class="panel-title" style="margin-bottom:2px;">
                <span>Requisitos No Funcionales (ISO/IEC 25010)</span>
                <span class="tag-count">${story.rnfs.length} métrica${story.rnfs.length > 1 ? 's' : ''}</span>
              </div>
              <div class="rnf-list">
                ${story.rnfs.map((rnf) => `
                  <div class="rnf-item">
                    <div class="rnf-cat">${escapeHtml(rnf.category)}</div>
                    <div class="rnf-desc">${escapeHtml(rnf.detail)}</div>
                  </div>
                `).join('')}
              </div>
              <div class="ui-note">
                <strong>Nota de interfaz:</strong> ${escapeHtml(story.uiNote)}
              </div>
            </div>
          </div>

          <!-- Columna Derecha -->
          <div class="story-col">
            <div class="panel" style="flex:1; display:flex; flex-direction:column;">
              <div class="panel-title">
                <span>3C · Confirmación — Criterios de Aceptación (Gherkin)</span>
                <span class="tag-count">${story.criteria.length} escenarios</span>
              </div>
              <div class="gherkin-list">
                ${story.criteria.map((c) => `
                  <div class="gherkin-card">
                    <div class="gherkin-head">
                      <span class="gherkin-id">${c.id}</span>
                      <span class="gherkin-name">${escapeHtml(c.name)}</span>
                    </div>
                    <div class="gherkin-body">
                      <span class="gherkin-kw">Dado que</span> ${escapeHtml(c.dado)};
                      <span class="gherkin-kw">Cuando</span> ${escapeHtml(c.cuando)};
                      <span class="gherkin-kw">Entonces</span> ${escapeHtml(c.entonces)}.
                    </div>
                  </div>
                `).join('')}
              </div>

              <div class="invest-strip" style="margin-top:10px;">
                <span class="invest-label">Validación INVEST</span>
                <div class="invest-pills">
                  ${investKeys.map((item) => {
                    const ok = Boolean(story.invest[item.key]);
                    return `<span class="invest-pill ${ok ? 'is-yes' : 'is-no'}" title="${item.label}: ${ok ? 'Cumple' : 'Dependencia / pendiente'}">${item.key} ${ok ? '✓' : '·'}</span>`;
                  }).join('')}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      ${renderFooter(slideNum, totalSlides, `${story.id} · ${story.epic}`)}
    </section>
  `;
};
