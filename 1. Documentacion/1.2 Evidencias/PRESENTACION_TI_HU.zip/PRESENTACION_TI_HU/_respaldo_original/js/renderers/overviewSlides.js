/**
 * ============================================================================
 * RENDERIZADORES: CONTEXTO, FLUJO DIVISAS, STAKEHOLDERS, ÉPICAS, TRAZABILIDAD, CIERRE
 * ============================================================================
 */
window.PresentationApp = window.PresentationApp || {};
window.PresentationApp.Renderers = window.PresentationApp.Renderers || {};

window.PresentationApp.Renderers.contextSlide = function renderContextSlide(slideNum, totalSlides) {
  const { CONTEXT } = window.PresentationApp;
  const { renderTopbar, renderFooter } = window.PresentationApp.UI;

  return `
    <section class="slide" data-slide-title="Contexto y Metodología 3C" data-slide-group="Introducción">
      ${renderTopbar('Contexto · Entrevista ENT-01')}
      <div class="slide-body">
        <div class="eyebrow">Técnica de Elicitación</div>
        <h2 class="slide-heading">Origen de las Historias de Usuario y Enfoque 3C</h2>
        <p class="slide-subtitle">
          Las 18 historias consolidan las necesidades levantadas en la entrevista <strong>ENT-01</strong> para digitalizar la compra de divisas en dos ventanillas, garantizando trazabilidad directa con los requisitos del acta.
        </p>

        <div class="kpi-strip" style="margin-top: 12px;">
          ${CONTEXT.kpis.map((k) => `
            <div class="kpi-card ${k.accent || ''}">
              <div class="kpi-value">${k.value}</div>
              <div class="kpi-label">${k.label}</div>
              <div class="kpi-desc">${k.desc}</div>
            </div>
          `).join('')}
        </div>

        <div class="context-grid">
          <div class="panel">
            <div class="panel-title">
              <span>Estructura 3C aplicada en cada tarjeta</span>
              <span class="tag-count">Estándar ágil</span>
            </div>
            <div class="three-c-list">
              ${CONTEXT.threeC.map((item) => `
                <div class="three-c-item">
                  <div class="three-c-num">${item.code}</div>
                  <div>
                    <h4>${item.title}</h4>
                    <p>${item.desc}</p>
                  </div>
                </div>
              `).join('')}
            </div>
          </div>

          <div class="panel">
            <div class="panel-title">
              <span>Priorización MoSCoW del Catálogo</span>
              <span class="tag-count">18 Historias</span>
            </div>
            <div class="moscow-legend">
              ${CONTEXT.moscowSummary.map((m) => `
                <div class="moscow-box">
                  <span class="badge badge-moscow-${m.code}">${m.code} · ${m.count} HUs</span>
                  <p><strong>${m.label}:</strong> ${m.desc}</p>
                </div>
              `).join('')}
            </div>
          </div>
        </div>
      </div>
      ${renderFooter(slideNum, totalSlides, 'Contexto y Enfoque 3C')}
    </section>
  `;
};

window.PresentationApp.Renderers.fxFlowSlide = function renderFxFlowSlide(slideNum, totalSlides) {
  const { fxFlow } = window.PresentationApp.CONTEXT;
  const { renderTopbar, renderFooter } = window.PresentationApp.UI;

  return `
    <section class="slide" data-slide-title="Flujo de Compra de Divisas" data-slide-group="Dominio del Negocio">
      ${renderTopbar('Dominio · Compra de Divisas')}
      <div class="slide-body">
        <div class="eyebrow">Proceso de Negocio · Casa de Cambio</div>
        <h2 class="slide-heading">Flujo Operativo de Compra de Divisas en Ventanilla</h2>
        <p class="slide-subtitle">
          Recorrido completo de una jornada desde la apertura (08:30) hasta el cierre y envío de reporte, mapeado a cada Historia de Usuario.
        </p>

        <div class="fx-flow-steps">
          ${fxFlow.steps.map((st) => `
            <div class="fx-step-card ${st.accent ? 'is-accent' : ''}">
              <span class="fx-step-num">${st.num}</span>
              <h4>${st.title}</h4>
              <p>${st.desc}</p>
              <div class="fx-step-hus">
                ${st.hus.map((id) => `<button type="button" class="trace-link" data-goto-story="${id}">${id}</button>`).join('')}
              </div>
            </div>
          `).join('')}
        </div>

        <div class="fx-domain-grid">
          <div class="panel">
            <div class="panel-title">
              <span>Divisas Operadas y Sentido de Conversión hacia USD</span>
              <span class="tag-count">Catálogo ENT-01 (P-11)</span>
            </div>
            <div class="currency-grid">
              ${fxFlow.currencies.map((c) => `
                <div class="currency-tile">
                  <div class="currency-tile-top">
                    <span class="currency-code">${c.code}</span>
                    <span class="currency-op">${c.op}</span>
                  </div>
                  <div class="currency-name">${c.name}</div>
                  <div class="currency-freq">${c.freq}</div>
                </div>
              `).join('')}
            </div>
          </div>

          <div class="panel">
            <div class="panel-title">
              <span>Reglas Clave del Negocio Cambiario</span>
              <span class="tag-count">Operación diaria</span>
            </div>
            <div class="fx-rules-box">
              ${fxFlow.keyRules.map((r) => `
                <div class="fx-rule-row">
                  <strong>${r.title}:</strong> ${r.text}
                </div>
              `).join('')}
            </div>
          </div>
        </div>
      </div>
      ${renderFooter(slideNum, totalSlides, 'Flujo de Compra de Divisas')}
    </section>
  `;
};

window.PresentationApp.Renderers.stakeholdersSlide = function renderStakeholdersSlide(slideNum, totalSlides) {
  const { CONTEXT, CONFIG } = window.PresentationApp;
  const { renderTopbar, renderFooter } = window.PresentationApp.UI;

  return `
    <section class="slide" data-slide-title="Stakeholders Internos y Externos" data-slide-group="Introducción">
      ${renderTopbar('Actores y Partes Interesadas')}
      <div class="slide-body">
        <div class="eyebrow">Identificación de Roles</div>
        <h2 class="slide-heading">Stakeholders Internos, Externos y Enlace con el Negocio</h2>
        <p class="slide-subtitle">
          Separación clara entre quien origina y valida la necesidad del negocio (Product Owner), los actores operativos y las entidades externas.
        </p>

        <div class="stakeholders-layout">
          <div class="po-highlight">
            <div>
              <div class="po-highlight-tag">Product Owner · Solicitante y Enlace Directo del Cliente</div>
              <h3>${CONFIG.productOwner.name}</h3>
              <p>${CONFIG.productOwner.note} Es la fuente directa que valida cada necesidad y criterio de aceptación en las 18 historias.</p>
            </div>
            <div class="po-badge-ref">Fuente: ENT-01 · DEC-01-01</div>
          </div>

          <div class="panel">
            <div class="panel-title">
              <span>Stakeholders Internos</span>
              <span class="tag-count">Operación y Desarrollo</span>
            </div>
            <div class="stakeholder-list">
              ${CONTEXT.stakeholders.internal.map((s) => `
                <div class="stakeholder-card">
                  <div class="stakeholder-card-head">
                    <h4>${s.name}</h4>
                    <span class="badge badge-neutral">${s.tag}</span>
                  </div>
                  <p>${s.desc}</p>
                </div>
              `).join('')}
            </div>
          </div>

          <div class="panel">
            <div class="panel-title">
              <span>Stakeholders Externos</span>
              <span class="tag-count">Entorno y Normativa</span>
            </div>
            <div class="stakeholder-list">
              ${CONTEXT.stakeholders.external.map((s) => `
                <div class="stakeholder-card">
                  <div class="stakeholder-card-head">
                    <h4>${s.name}</h4>
                    <span class="badge badge-gold">${s.tag}</span>
                  </div>
                  <p>${s.desc}</p>
                </div>
              `).join('')}
            </div>
          </div>
        </div>
      </div>
      ${renderFooter(slideNum, totalSlides, 'Stakeholders y Roles')}
    </section>
  `;
};

window.PresentationApp.Renderers.epicsSlide = function renderEpicsSlide(slideNum, totalSlides) {
  const { STORIES } = window.PresentationApp;
  const { renderTopbar, renderFooter } = window.PresentationApp.UI;

  const groups = [
    {
      title: '1. Gestión de Tasas',
      subtitle: 'Autorización y referencia diaria',
      items: STORIES.filter((s) => s.epic === 'Gestión de tasas')
    },
    {
      title: '2. Atención de Compra',
      subtitle: 'Cálculo, registro, control y comprobante',
      items: STORIES.filter((s) => s.epic === 'Atención de compra')
    },
    {
      title: '3. Continuidad Operativa',
      subtitle: 'Operación sin Internet y recuperación',
      items: STORIES.filter((s) => s.epic === 'Continuidad operativa')
    },
    {
      title: '4. Caja, Cierre y Cumplimiento',
      subtitle: 'Capital, gastos, cuadre, reporte y UAFE',
      items: STORIES.filter((s) => s.epic === 'Caja y cierre' || s.epic === 'Cumplimiento normativo')
    }
  ];

  return `
    <section class="slide" data-slide-title="Mapa de Épicas (18 HUs)" data-slide-group="Introducción">
      ${renderTopbar('Catálogo Funcional')}
      <div class="slide-body">
        <div class="eyebrow">Arquitectura Funcional · Navegación Interactiva</div>
        <h2 class="slide-heading">Mapa de las 18 Historias de Usuario por Épica</h2>
        <p class="slide-subtitle">
          Haz clic en cualquier historia para ir directamente a su especificación completa (Tarjeta, Reglas de Negocio, Criterios Gherkin y RNF).
        </p>

        <div class="epics-grid">
          ${groups.map((g) => `
            <div class="epic-card">
              <div class="epic-card-head">
                <div>
                  <div class="epic-card-title">${g.title}</div>
                  <div style="font-size:10.5px; color:var(--text-muted);">${g.subtitle}</div>
                </div>
                <span class="badge badge-neutral">${g.items.length} HUs</span>
              </div>
              <div class="epic-hu-list">
                ${g.items.map((st) => `
                  <button type="button" class="epic-hu-btn" data-goto-story="${st.id}">
                    <span class="epic-hu-id">${st.id}</span>
                    <span class="epic-hu-name">${st.title}</span>
                    <span class="epic-hu-role">${st.role.startsWith('Prop') ? 'Propietaria' : 'Operadora'}</span>
                    <span class="badge badge-moscow-${st.moscow}" style="padding:1.5px 6px; font-size:9.5px;">${st.moscow}</span>
                  </button>
                `).join('')}
              </div>
            </div>
          `).join('')}
        </div>
      </div>
      ${renderFooter(slideNum, totalSlides, 'Mapa de Épicas')}
    </section>
  `;
};

window.PresentationApp.Renderers.traceabilitySlide = function renderTraceabilitySlide(slideNum, totalSlides) {
  const { CONTEXT } = window.PresentationApp;
  const { renderTopbar, renderFooter } = window.PresentationApp.UI;

  const col1 = CONTEXT.traceability.slice(0, 11);
  const col2 = CONTEXT.traceability.slice(11, 21);
  const col3 = CONTEXT.traceability.slice(21);

  const renderTable = (rows) => `
    <div class="panel" style="padding:0; overflow:hidden;">
      <table class="trace-table">
        <thead>
          <tr>
            <th style="width:86px;">Requisito</th>
            <th>Historia(s) asociada(s)</th>
          </tr>
        </thead>
        <tbody>
          ${rows.map((r) => `
            <tr>
              <td>${r.req}</td>
              <td>
                ${r.hus
                  ? r.hus.map((id) => `<button type="button" class="trace-link" data-goto-story="${id}">${id}</button>`).join('')
                  : `<span>${r.text}</span>`
                }
              </td>
            </tr>
          `).join('')}
        </tbody>
      </table>
    </div>
  `;

  return `
    <section class="slide" data-slide-title="Matriz de Trazabilidad ENT-01" data-slide-group="Cierre">
      ${renderTopbar('Trazabilidad de Requisitos')}
      <div class="slide-body">
        <div class="eyebrow">Cobertura Completa</div>
        <h2 class="slide-heading">Matriz de Trazabilidad: Acta ENT-01 ↔ Historias de Usuario</h2>
        <p class="slide-subtitle">
          Verificación de cobertura del 100 % de los requisitos funcionales (RF-01 a RF-20), atributos no funcionales (ISO/IEC 25010), restricción de interfaz y reglas de negocio.
        </p>

        <div class="trace-grid">
          ${renderTable(col1)}
          ${renderTable(col2)}
          ${renderTable(col3)}
        </div>

        <div class="trace-note">
          <strong>Nota de validación:</strong> ${CONTEXT.traceNote}
        </div>
      </div>
      ${renderFooter(slideNum, totalSlides, 'Matriz de Trazabilidad')}
    </section>
  `;
};

window.PresentationApp.Renderers.closingSlide = function renderClosingSlide() {
  const { institution, course, members, productOwner } = window.PresentationApp.CONFIG;

  return `
    <section class="slide slide-closing" data-slide-title="Cierre y Preguntas" data-slide-group="Cierre">
      <div class="closing-content">
        <div class="closing-logo-badge">
          <img src="${institution.logoHorizontal}" alt="Logotipo oficial ${institution.shortName}" />
        </div>
        <div class="closing-eyebrow">${institution.department} · ${institution.career}</div>
        <h2 class="closing-title">Muchas Gracias</h2>
        <p class="closing-desc">
          Especificación completa de las 18 Historias de Usuario del <strong>Sistema de Compra de Divisas</strong>, validadas con trazabilidad directa a la entrevista <strong>ENT-01</strong> y criterios verificables en Gherkin.
        </p>

        <div class="closing-stats">
          <div class="closing-stat">
            <strong>18</strong>
            <span>Historias de Usuario</span>
          </div>
          <div class="closing-stat">
            <strong>100%</strong>
            <span>Cobertura RF-01 a RF-20</span>
          </div>
          <div class="closing-stat">
            <strong>3C</strong>
            <span>Tarjeta · Conversación · Confirmación</span>
          </div>
          <div class="closing-stat">
            <strong>NRC ${course.nrc}</strong>
            <span>${course.group}</span>
          </div>
        </div>

        <div class="closing-meta">
          <strong>Integrantes:</strong> ${members.join(' · ')} &nbsp;|&nbsp;
          <strong>Product Owner:</strong> ${productOwner.name}
        </div>
      </div>
    </section>
  `;
};
