/**
 * ============================================================================
 * RENDERIZADOR: DIAPOSITIVA DE PORTADA INSTITUCIONAL ESPE
 * ============================================================================
 */
window.PresentationApp = window.PresentationApp || {};
window.PresentationApp.Renderers = window.PresentationApp.Renderers || {};

window.PresentationApp.Renderers.coverSlide = function renderCoverSlide() {
  const { institution, course, presentation, members, productOwner } = window.PresentationApp.CONFIG;

  return `
    <section class="slide slide-cover" data-slide-title="Portada Institucional" data-slide-group="Inicio">
      <aside class="cover-sidebar">
        <div class="cover-emblem-wrap">
          <div class="cover-shield-card">
            <img class="cover-shield-img" src="${institution.logoShield}" alt="Escudo oficial ${institution.shortName}" />
          </div>
          <div>
            <div class="cover-uni-name">${institution.name}</div>
            <div class="cover-uni-dept">${institution.department}<br/>${institution.career}</div>
          </div>
        </div>

        <div class="cover-nrc-box">
          <div class="cover-nrc-label">Asignatura · NRC</div>
          <div class="cover-nrc-value">NRC ${course.nrc}</div>
          <div class="cover-nrc-sub">${course.subject}<br/>${course.group} · ${course.date}</div>
        </div>
      </aside>

      <main class="cover-main">
        <div>
          <div class="cover-top-row">
            <img class="cover-horizontal-logo" src="${institution.logoHorizontal}" alt="Logotipo oficial ${institution.shortName}" />
            <div class="cover-tag">
              <span class="cover-tag-dot"></span>
              <span>${presentation.techniqueTag}</span>
            </div>
          </div>

          <div class="cover-title-block">
            <h1 class="cover-title">${presentation.titleMain}<br/><span>${presentation.titleHighlight}</span></h1>
            <div class="cover-accent-line"></div>
            <p class="cover-desc">${presentation.subtitle}</p>
          </div>

          <div class="cover-fx-strip">
            <span class="fx-strip-label">Dominio · Divisas</span>
            <div class="fx-pills">
              <span class="fx-pill">EUR €</span>
              <span class="fx-pill">COP $</span>
              <span class="fx-pill">PEN S/</span>
              <span class="fx-pill">BRL R$</span>
              <span class="fx-pill">GBP £</span>
              <span class="fx-pill">CLP $</span>
              <span class="fx-arrow">→</span>
              <span class="fx-pill is-usd">USD $ Efectivo</span>
            </div>
          </div>
        </div>

        <div class="cover-meta-grid">
          <div>
            <div class="cover-meta-label">Integrantes · ${course.group}</div>
            <div class="cover-members">
              ${members.map((m) => `<span class="member-pill">${m}</span>`).join('')}
            </div>
          </div>
          <div>
            <div class="cover-meta-label">Fuente y Validación</div>
            <div class="cover-details-list">
              <span><strong>Product Owner:</strong> ${productOwner.name}</span>
              <span><strong>Entrevista base:</strong> ENT-01 (v1.1 · 18/11/2026)</span>
              <span><strong>Alcance:</strong> 18 Historias de Usuario (HU-01 a HU-18)</span>
            </div>
          </div>
        </div>
      </main>
    </section>
  `;
};
