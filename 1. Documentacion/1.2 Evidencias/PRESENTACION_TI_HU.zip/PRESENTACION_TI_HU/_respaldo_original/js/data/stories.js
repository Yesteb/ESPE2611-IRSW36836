/**
 * ============================================================================
 * CATÁLOGO MODULAR DE LAS 18 HISTORIAS DE USUARIO (HU-01 a HU-18)
 * Fuente: Entrevista ENT-01 (v1.1 validada por E1) · Sistema de Compra de Divisas
 * Nota: Sin referencias a Sprints; enfoque puro en especificación 3C de HU.
 * ============================================================================
 */
window.PresentationApp = window.PresentationApp || {};

window.PresentationApp.STORIES = [
  {
    id: 'HU-01',
    title: 'Registrar las tasas de compra del día',
    epic: 'Gestión de tasas',
    role: 'Propietaria de la casa de cambio',
    moscow: 'M',
    points: 5,
    businessValue: 'Alto',
    techRisk: 'Bajo',
    dependsOn: 'Ninguna',
    source: 'RF-04, RF-05, RN-02 · ENT-01 (DEC-01-05, DEC-01-07, DEC-01-21)',
    card: {
      como: 'propietaria de la casa de cambio',
      quiero: 'registrar cada mañana la tasa de compra de cada divisa y si su valor se multiplica o se divide',
      para: 'que las operadoras apliquen únicamente las tasas que yo autoricé'
    },
    rules: [
      { id: 'RN-01', text: 'Las tasas ordinarias las define la propietaria; se revisan cada mañana y pueden cambiar durante el día (DEC-01-05).' },
      { id: 'RN-02', text: 'Cada divisa tiene un sentido de operación fijo: multiplicar o dividir (DEC-01-21).' },
      { id: 'RN-03', text: 'Una tasa nueva no altera compras ya registradas: cada compra conserva su tasa original (RF-05).' },
      { id: 'RN-04', text: 'Divisas iniciales: EUR, COP y PEN; con menor frecuencia BRL, GBP y CLP. Catálogo de 10 divisas a validar en P-11.' },
      { id: 'RN-05', text: 'Mientras la propietaria esté fuera del país, permisos de ingreso de tasa se definen en P-04.' }
    ],
    criteria: [
      {
        id: 'CA-01',
        name: 'Registro de una tasa',
        dado: 'la propietaria inició sesión y el euro no tiene tasa para hoy',
        cuando: 'registra 1,08 con sentido “multiplicar” y confirma',
        entonces: 'se guarda con fecha-hora de vigencia y se muestra en las dos ventanillas en ≤ 5 s'
      },
      {
        id: 'CA-02',
        name: 'Cambio de tasa durante el día',
        dado: 'hay 3 compras de euro registradas con la tasa 1,08',
        cuando: 'la propietaria registra una tasa nueva de 1,06',
        entonces: 'las compras nuevas usan 1,06 y las 3 anteriores conservan 1,08'
      },
      {
        id: 'CA-03',
        name: 'Dato inválido',
        dado: 'la propietaria está registrando una tasa',
        cuando: 'ingresa 0, un valor negativo o deja vacío el sentido de operación',
        entonces: 'el sistema no guarda la tasa y señala el campo con error'
      },
      {
        id: 'CA-04',
        name: 'Bitácora del cambio',
        dado: 'la tasa vigente del euro es 1,08',
        cuando: 'se cambia a 1,06',
        entonces: 'la bitácora registra usuario, fecha-hora, valor anterior y nuevo sin permitir edición'
      }
    ],
    rnfs: [
      { category: 'Seguridad – No repudio', detail: 'RNF-06: 100 % de cambios en bitácora inalterable (0 registros alterables en 20 pruebas).' },
      { category: 'Corrección funcional', detail: 'Tasa disponible en ambas ventanillas en ≤ 5 s con igual valor y sentido (100 %).' }
    ],
    uiNote: 'Pantalla “Tasas del día” para computadora (RES-01): lista vigente, sentido, vigencia y acceso a bitácora.',
    invest: { I: true, N: true, V: true, E: true, S: true, T: true }
  },
  {
    id: 'HU-02',
    title: 'Consultar la cotización global de referencia',
    epic: 'Gestión de tasas',
    role: 'Propietaria de la casa de cambio',
    moscow: 'S',
    points: 3,
    businessValue: 'Medio',
    techRisk: 'Alto',
    dependsOn: 'HU-01',
    source: 'RF-06 · ENT-01 (DEC-01-07, DEC-01-19)',
    card: {
      como: 'propietaria de la casa de cambio',
      quiero: 'ver la cotización global de cada divisa junto a la tasa vigente',
      para: 'decidir la tasa del día sin buscarla en otra página web'
    },
    rules: [
      { id: 'RN-01', text: 'La cotización global es solo una referencia: nunca se aplica directamente a una compra (RN-02).' },
      { id: 'RN-02', text: 'La fuente externa, condiciones de uso y frecuencia se definen en P-09 (motivo del riesgo técnico alto).' },
      { id: 'RN-03', text: 'Sin conexión a Internet se muestra la última cotización consultada con su fecha-hora.' }
    ],
    criteria: [
      {
        id: 'CA-01',
        name: 'Consulta con conexión',
        dado: 'hay conexión y la fuente aprobada en P-09 está configurada',
        cuando: 'la propietaria abre “Tasas del día”',
        entonces: 'muestra la cotización global de cada divisa con fecha-hora en ≤ 10 s'
      },
      {
        id: 'CA-02',
        name: 'Consulta sin conexión',
        dado: 'no hay conexión a Internet',
        cuando: 'la propietaria abre “Tasas del día”',
        entonces: 'muestra la última cotización guardada, fecha-hora y aviso “Sin conexión: cotización no actualizada”'
      },
      {
        id: 'CA-03',
        name: 'La referencia no se aplica',
        dado: 'la cotización global del euro es 1,10 y la tasa vigente es 1,08',
        cuando: 'una operadora calcula una compra de euros',
        entonces: 'el sistema aplica estrictamente 1,08'
      }
    ],
    rnfs: [
      { category: 'Compatibilidad – Interoperabilidad', detail: '≥ 95 % de consultas exitosas a la fuente aprobada en P-09 durante una semana de prueba.' },
      { category: 'Eficiencia de desempeño', detail: 'Despliegue de la cotización en ≤ 10 s con conexión estable.' }
    ],
    uiNote: 'Columna adicional “Cotización global” en “Tasas del día” con fecha-hora de consulta.',
    invest: { I: false, N: true, V: true, E: true, S: true, T: true }
  },
  {
    id: 'HU-03',
    title: 'Calcular el equivalente en USD de una compra',
    epic: 'Atención de compra',
    role: 'Operadora de ventanilla',
    moscow: 'M',
    points: 5,
    businessValue: 'Alto',
    techRisk: 'Medio',
    dependsOn: 'HU-01',
    source: 'RF-02, RF-03 · ENT-01 (DEC-01-06, DEC-01-20, DEC-01-21)',
    card: {
      como: 'operadora de ventanilla',
      quiero: 'ingresar la divisa y la cantidad que entrega el cliente y ver al instante cuántos dólares debo pagar',
      para: 'atender sin hacer cálculos manuales y sin equivocarme'
    },
    rules: [
      { id: 'RN-01', text: 'El cálculo usa la tasa vigente y el sentido registrado para la divisa: multiplicar o dividir (DEC-01-21).' },
      { id: 'RN-02', text: 'El resultado se muestra antes de confirmar para informarlo al cliente (RF-03).' },
      { id: 'RN-03', text: 'El resultado se redondea a 2 decimales; la regla exacta de redondeo se valida en P-11.' },
      { id: 'RN-04', text: 'Las tasas mostradas en los criterios de aceptación son datos de prueba, no tasas reales.' }
    ],
    criteria: [
      {
        id: 'CA-01',
        name: 'Divisa que se multiplica',
        dado: 'la tasa del euro es 1,08 con sentido “multiplicar”',
        cuando: 'la operadora ingresa EUR 250',
        entonces: 'el sistema muestra USD 270,00 en ≤ 1 s'
      },
      {
        id: 'CA-02',
        name: 'Divisa que se divide',
        dado: 'la tasa del peso colombiano es 4.100 con sentido “dividir”',
        cuando: 'la operadora ingresa COP 400.000',
        entonces: 'el sistema muestra USD 97,56 en ≤ 1 s'
      },
      {
        id: 'CA-03',
        name: 'Divisa sin tasa',
        dado: 'el real brasileño no tiene tasa vigente para hoy',
        cuando: 'la operadora selecciona real',
        entonces: 'no calcula y muestra “Divisa sin tasa autorizada para hoy”'
      },
      {
        id: 'CA-04',
        name: 'Cantidad inválida',
        dado: 'la operadora seleccionó euro',
        cuando: 'ingresa 0 o un valor negativo',
        entonces: 'no calcula y señala el campo con error'
      }
    ],
    rnfs: [
      { category: 'Corrección funcional', detail: 'RNF-05: Diferencia ≤ USD 0,01 respecto a referencia en 100 % de ≥ 30 casos por divisa.' },
      { category: 'Eficiencia temporal', detail: 'RNF-01a: Equivalente en USD con p95 ≤ 1 s (mínimo aceptable p95 ≤ 2 s) en 2 ventanillas.' }
    ],
    uiNote: 'Pantalla “Nueva compra” (RES-01): selector de divisa, cantidad, tasa vigente, resultado en USD y botón “Confirmar”.',
    invest: { I: false, N: true, V: true, E: true, S: true, T: true }
  },
  {
    id: 'HU-04',
    title: 'Registrar la compra confirmada',
    epic: 'Atención de compra',
    role: 'Operadora de ventanilla',
    moscow: 'M',
    points: 5,
    businessValue: 'Alto',
    techRisk: 'Medio',
    dependsOn: 'HU-03',
    source: 'RF-01, RF-05, RN-01 · ENT-01 (DEC-01-08, DEC-01-10, DEC-01-18, DEC-01-25)',
    card: {
      como: 'operadora de ventanilla',
      quiero: 'confirmar la compra después de pagar al cliente y que quede registrada automáticamente',
      para: 'dejar de anotar cada operación en el cuaderno'
    },
    rules: [
      { id: 'RN-01', text: 'El pago se realiza exclusivamente en dólares en efectivo (RN-01 / DEC-01-08).' },
      { id: 'RN-02', text: 'Cada registro guarda divisa, cantidad, tasa aplicada, USD entregados, fecha-hora, ventanilla y usuario.' },
      { id: 'RN-03', text: 'No se piden datos del cliente en compras ordinarias (DEC-01-11); excepción tratada en HU-18.' },
      { id: 'RN-04', text: 'Ambas ventanillas pueden registrar compras simultáneamente (DEC-01-25).' },
      { id: 'RN-05', text: 'La atención completa dura ≤ 5 min (DEC-01-14); el registro digital ocupa solo una fracción.' }
    ],
    criteria: [
      {
        id: 'CA-01',
        name: 'Registro exitoso',
        dado: 'la operadora calculó EUR 250 = USD 270,00',
        cuando: 'confirma la compra',
        entonces: 'se guarda con todos sus datos y muestra número de operación en ≤ 2 s'
      },
      {
        id: 'CA-02',
        name: 'Dos ventanillas a la vez',
        dado: 'ambas ventanillas confirman una compra en el mismo segundo',
        cuando: 'el sistema las guarda',
        entonces: 'quedan 2 compras distintas, sin duplicados ni sobrescritura'
      },
      {
        id: 'CA-03',
        name: 'Cliente desiste',
        dado: 'el cliente no acepta tras ver el cálculo',
        cuando: 'la operadora cancela',
        entonces: 'no se registra operación ni cambia el efectivo disponible'
      },
      {
        id: 'CA-04',
        name: 'Tiempo de registro',
        dado: 'la operadora recibió ≤ 30 min de capacitación',
        cuando: 'registra 20 compras ordinarias de EUR, COP y PEN',
        entonces: 'el p90 desde ingreso de divisa hasta confirmación es ≤ 2 min'
      }
    ],
    rnfs: [
      { category: 'Operabilidad', detail: 'RNF-01b: Registro de compra ordinaria con p90 ≤ 2 min (mínimo aceptable p90 ≤ 3 min).' },
      { category: 'Seguridad – Integridad', detail: 'RNF-03: 0 pérdidas, duplicados o sobrescrituras en 100 pares simultáneos desde 2 equipos.' }
    ],
    uiNote: 'Confirmación en “Nueva compra” con número de operación, divisa, tasa, USD, fecha-hora, ventanilla y usuario.',
    invest: { I: false, N: true, V: true, E: true, S: true, T: true }
  },
  {
    id: 'HU-05',
    title: 'Controlar el efectivo disponible antes de pagar',
    epic: 'Atención de compra',
    role: 'Operadora de ventanilla',
    moscow: 'S',
    points: 3,
    businessValue: 'Medio',
    techRisk: 'Bajo',
    dependsOn: 'HU-04, HU-12',
    source: 'RF-09, RF-10 · ENT-01 (DEC-01-24, preguntas 10 y 18)',
    card: {
      como: 'operadora de ventanilla',
      quiero: 'ver el efectivo en dólares que me queda y recibir una advertencia si no alcanza para una compra',
      para: 'no comprometer un pago que no puedo cubrir'
    },
    rules: [
      { id: 'RN-01', text: 'Fórmula: Efectivo disponible = capital inicial + ingresos adicionales − USD pagados en compras − gastos.' },
      { id: 'RN-02', text: 'Si no alcanza, se contacta a la propietaria y se ofrece esperar (30–40 min) o pago parcial (límites en P-12).' },
      { id: 'RN-03', text: 'La advertencia es informativa y no bloquea la compra: la decisión corresponde a operadora y propietaria.' },
      { id: 'RN-04', text: 'Se asume un solo fondo de efectivo compartido para las dos ventanillas (a confirmar con E1 en P-12).' }
    ],
    criteria: [
      {
        id: 'CA-01',
        name: 'Saldo actualizado',
        dado: 'el capital inicial es USD 5.000,00',
        cuando: 'se confirma una compra de USD 270,00',
        entonces: 'el efectivo disponible mostrado pasa a USD 4.730,00 en ≤ 2 s'
      },
      {
        id: 'CA-02',
        name: 'Efectivo insuficiente',
        dado: 'el efectivo disponible es USD 300,00',
        cuando: 'la operadora calcula una compra de USD 450,00',
        entonces: 'antes de confirmar aparece “Efectivo insuficiente: faltan USD 150,00”'
      },
      {
        id: 'CA-03',
        name: 'Efectivo suficiente',
        dado: 'el efectivo disponible es USD 300,00',
        cuando: 'la operadora calcula una compra de USD 250,00',
        entonces: 'el sistema no muestra ninguna advertencia'
      }
    ],
    rnfs: [
      { category: 'Corrección funcional', detail: 'Coincidencia exacta al centavo con el cálculo manual en 100 % de 20 secuencias de prueba.' },
      { category: 'Eficiencia temporal', detail: 'Actualización del saldo en ≤ 2 s tras cada compra, gasto o ingreso.' }
    ],
    uiNote: 'Indicador permanente “Efectivo disponible” en pantalla de compra y alerta visible cuando el monto supera el saldo.',
    invest: { I: false, N: true, V: true, E: true, S: true, T: true }
  },
  {
    id: 'HU-06',
    title: 'Registrar la autorización de una compra de alto monto',
    epic: 'Atención de compra',
    role: 'Operadora de ventanilla',
    moscow: 'S',
    points: 5,
    businessValue: 'Medio',
    techRisk: 'Medio',
    dependsOn: 'HU-04',
    source: 'RF-18 · ENT-01 (DEC-01-03, DEC-01-07, preguntas 4, 30 y 43)',
    card: {
      como: 'operadora de ventanilla',
      quiero: 'registrar que la propietaria autorizó una compra de alto monto o una tasa especial antes de confirmarla',
      para: 'tener constancia de quién aprobó la operación'
    },
    rules: [
      { id: 'RN-01', text: 'Montos pequeños los resuelve la operadora; valores altos requieren autorización de la propietaria (DEC-01-03).' },
      { id: 'RN-02', text: 'El umbral exacto de “valor alto” será un parámetro configurable una vez acordado en P-01.' },
      { id: 'RN-03', text: 'Los criterios de prueba emplean un umbral referencial de USD 2.000,00.' },
      { id: 'RN-04', text: 'El medio de evidencia de autorización (llamada, mensaje, etc.) se definirá en P-01.' }
    ],
    criteria: [
      {
        id: 'CA-01',
        name: 'Monto sobre el umbral',
        dado: 'el umbral configurado es USD 2.000,00',
        cuando: 'la operadora calcula una compra de USD 2.500,00',
        entonces: 'el sistema solicita registrar autorización antes de habilitar “Confirmar”'
      },
      {
        id: 'CA-02',
        name: 'Autorización registrada',
        dado: 'el sistema solicitó la autorización',
        cuando: 'ingresa quién autorizó, fecha-hora y medio de comunicación',
        entonces: 'habilita “Confirmar” y guarda la autorización vinculada a la compra'
      },
      {
        id: 'CA-03',
        name: 'Tasa especial',
        dado: 'la tasa vigente del euro es 1,08',
        cuando: 'la operadora aplica 1,09 a una compra',
        entonces: 'el sistema exige registrar la autorización correspondiente'
      },
      {
        id: 'CA-04',
        name: 'Monto ordinario',
        dado: 'el umbral configurado es USD 2.000,00',
        cuando: 'calcula USD 1.500,00 con la tasa vigente',
        entonces: 'el sistema no solicita autorización'
      }
    ],
    rnfs: [
      { category: 'Seguridad – Responsabilidad', detail: '100 % de compras sobre umbral o con tasa especial con autorización registrada (0 omisiones).' },
      { category: 'Operabilidad', detail: 'El registro de la autorización deberá tomar ≤ 1 min para no demorar la atención.' }
    ],
    uiNote: 'Ventana modal “Autorización” (autorizador, fecha-hora, medio). Umbral parametrizable fuera del código.',
    invest: { I: false, N: true, V: true, E: true, S: true, T: true }
  },
  {
    id: 'HU-07',
    title: 'Emitir la nota de venta',
    epic: 'Atención de compra',
    role: 'Operadora de ventanilla',
    moscow: 'S',
    points: 3,
    businessValue: 'Medio',
    techRisk: 'Bajo',
    dependsOn: 'HU-04',
    source: 'RF-12 · ENT-01 (DEC-01-26, DEC-01-27, preguntas 26 y 47)',
    card: {
      como: 'operadora de ventanilla',
      quiero: 'imprimir la nota de venta de una compra cuando el cliente la pida',
      para: 'entregarle un comprobante sin escribirlo a mano'
    },
    rules: [
      { id: 'RN-01', text: 'La nota de venta se emite únicamente cuando el cliente la solicita (DEC-01-26).' },
      { id: 'RN-02', text: 'Incluye divisa, cantidad, tasa aplicada, USD entregados, fecha y espacios para firma y sello (DEC-01-27).' },
      { id: 'RN-03', text: 'No incluye datos personales del cliente; campos legales mínimos y archivo de copias se validan en P-07.' }
    ],
    criteria: [
      {
        id: 'CA-01',
        name: 'Emisión',
        dado: 'hay una compra registrada de EUR 250 con tasa 1,08 y USD 270,00',
        cuando: 'la operadora solicita la nota de venta',
        entonces: 'genera en ≤ 5 s una nota imprimible con esos datos, fecha, N.º de operación, firma y sello'
      },
      {
        id: 'CA-02',
        name: 'Compra sin confirmar',
        dado: 'la compra aún no está confirmada',
        cuando: 'la operadora intenta emitir la nota',
        entonces: 'no la emite y muestra “Confirme la compra antes de emitir la nota”'
      },
      {
        id: 'CA-03',
        name: 'Reimpresión',
        dado: 'la nota de una compra ya fue emitida previamente',
        cuando: 'la operadora la vuelve a solicitar',
        entonces: 'emite la misma nota identificada como “Copia”'
      }
    ],
    rnfs: [
      { category: 'Corrección funcional', detail: '100 % de las notas coincide exactamente con divisa, cantidad, tasa y USD de la compra.' },
      { category: 'Eficiencia temporal', detail: 'Generación del comprobante imprimible en ≤ 5 s.' }
    ],
    uiNote: 'Botón “Nota de venta” en el detalle de la compra con formato imprimible en media hoja (ajustable en P-07).',
    invest: { I: false, N: true, V: true, E: true, S: true, T: true }
  },
  {
    id: 'HU-08',
    title: 'Corregir una compra registrada',
    epic: 'Atención de compra',
    role: 'Operadora de ventanilla',
    moscow: 'C',
    points: 5,
    businessValue: 'Medio',
    techRisk: 'Medio',
    dependsOn: 'HU-04',
    source: 'RF-19, RNF-06 · ENT-01 (DEC-01-09, preguntas 13 y 31)',
    card: {
      como: 'operadora de ventanilla',
      quiero: 'corregir una compra mal registrada indicando el motivo y conservando los datos originales',
      para: 'que el cuadre sea correcto sin perder la evidencia del error'
    },
    rules: [
      { id: 'RN-01', text: 'Actualmente no existe anulación formal: la diferencia la asume quien atendió (DEC-01-09).' },
      { id: 'RN-02', text: 'Una corrección nunca borra la compra: crea una nueva versión y conserva la original.' },
      { id: 'RN-03', text: 'Quién puede corregir y hasta qué momento límite se define en P-04.' },
      { id: 'RN-04', text: 'Clasificada como C (Podría) dado que E1 no la priorizó inicialmente (problema 10 del acta).' }
    ],
    criteria: [
      {
        id: 'CA-01',
        name: 'Corrección con motivo',
        dado: 'hay una compra registrada de EUR 250 con tasa 1,08',
        cuando: 'la operadora la corrige a EUR 200 e ingresa el motivo',
        entonces: 'recalcula USD 216,00, guarda versión original y nueva, y actualiza el efectivo disponible'
      },
      {
        id: 'CA-02',
        name: 'Corrección sin motivo',
        dado: 'la operadora está corrigiendo una compra',
        cuando: 'intenta guardar sin escribir el motivo',
        entonces: 'el sistema impide guardar y solicita obligatoriamente el motivo'
      },
      {
        id: 'CA-03',
        name: 'Historial visible',
        dado: 'una compra fue corregida',
        cuando: 'la propietaria consulta esa operación',
        entonces: 'visualiza valor original, valor nuevo, motivo, usuario y fecha-hora'
      }
    ],
    rnfs: [
      { category: 'Seguridad – No repudio', detail: 'RNF-06: 100 % de correcciones registradas con usuario, fecha-hora, valor anterior y nuevo (0 alterables en 10 pruebas).' }
    ],
    uiNote: 'Acción “Corregir” en detalle de compra con campo obligatorio de motivo y vista de historial de versiones.',
    invest: { I: false, N: true, V: true, E: true, S: true, T: true }
  },
  {
    id: 'HU-09',
    title: 'Buscar compras registradas',
    epic: 'Atención de compra',
    role: 'Propietaria de la casa de cambio',
    moscow: 'C',
    points: 3,
    businessValue: 'Bajo',
    techRisk: 'Bajo',
    dependsOn: 'HU-04',
    source: 'RF-17 · ENT-01 (DEC-01-10, DEC-01-18, pregunta 27)',
    card: {
      como: 'propietaria de la casa de cambio',
      quiero: 'buscar las compras por fecha y por divisa',
      para: 'revisar operaciones puntuales sin leer todo el registro del día'
    },
    rules: [
      { id: 'RN-01', text: 'E1 no indicó filtros específicos; fecha y divisa son la propuesta del equipo a validar en P-03.' },
      { id: 'RN-02', text: 'No se permite búsqueda por cliente porque no se registran datos personales (DEC-01-11).' }
    ],
    criteria: [
      {
        id: 'CA-01',
        name: 'Búsqueda con filtros',
        dado: 'hay 120 compras registradas entre el 1 y 15 de diciembre',
        cuando: 'la propietaria filtra euro del 10/12/2026',
        entonces: 'lista solo esas compras en ≤ 3 s con los totales en euros y en USD'
      },
      {
        id: 'CA-02',
        name: 'Sin resultados',
        dado: 'no existen compras de libra esterlina en la fecha elegida',
        cuando: 'aplica ese filtro',
        entonces: 'muestra el mensaje “No hay compras con esos filtros”'
      },
      {
        id: 'CA-03',
        name: 'Rango inválido',
        dado: 'la propietaria está filtrando por fechas',
        cuando: 'ingresa una fecha inicial posterior a la fecha final',
        entonces: 'no ejecuta la búsqueda y señala el rango con error'
      }
    ],
    rnfs: [
      { category: 'Eficiencia temporal', detail: 'Respuesta de búsqueda con p95 ≤ 3 s sobre un volumen de 10.000 compras almacenadas.' }
    ],
    uiNote: 'Pantalla “Compras” con filtros por rango de fechas y divisa, tabla de resultados y totales al pie.',
    invest: { I: false, N: true, V: true, E: true, S: true, T: true }
  },
  {
    id: 'HU-10',
    title: 'Atender compras sin conexión a Internet',
    epic: 'Continuidad operativa',
    role: 'Operadora de ventanilla',
    moscow: 'M',
    points: 13,
    businessValue: 'Alto',
    techRisk: 'Alto',
    dependsOn: 'HU-03, HU-04',
    source: 'RF-07, RF-20, RNF-02 · ENT-01 (DEC-01-16, DEC-01-23, preguntas 37 y 39)',
    card: {
      como: 'operadora de ventanilla',
      quiero: 'seguir calculando y registrando compras cuando se cae Internet',
      para: 'no detener la atención ni volver al cálculo manual'
    },
    rules: [
      { id: 'RN-01', text: 'E1 identificó las fallas de Internet como el principal obstáculo operativo (DEC-01-23).' },
      { id: 'RN-02', text: 'Sin conexión se utiliza la última tasa autorizada almacenada localmente, mostrando su fecha-hora.' },
      { id: 'RN-03', text: 'Si la tasa no es del día actual, pide confirmación y marca la compra para revisión en el cuadre (RF-20).' },
      { id: 'RN-04', text: 'Al restablecerse Internet, todas las compras se sincronizan sin pérdidas ni duplicados.' },
      { id: 'RN-05', text: 'La hora formal de cierre de jornada se confirma en P-05.' }
    ],
    criteria: [
      {
        id: 'CA-01',
        name: 'Cálculo sin conexión',
        dado: 'no hay conexión y la tasa de hoy del euro (1,08) está guardada',
        cuando: 'la operadora ingresa EUR 100',
        entonces: 'muestra USD 108,00 junto al indicador “Sin conexión”'
      },
      {
        id: 'CA-02',
        name: 'Tasa de otro día',
        dado: 'no hay conexión y la última tasa guardada es de ayer',
        cuando: 'la operadora calcula una compra',
        entonces: 'muestra fecha-hora de esa tasa, pide confirmar su uso y marca la compra para revisión'
      },
      {
        id: 'CA-03',
        name: 'Sincronización',
        dado: 'existen 20 compras registradas sin conexión entre las dos ventanillas',
        cuando: 'vuelve la conexión a Internet',
        entonces: 'el 100 % se sincroniza en ≤ 5 min sin pérdidas ni duplicados'
      },
      {
        id: 'CA-04',
        name: 'Jornada sin conexión',
        dado: 'no hay conexión desde la apertura',
        cuando: 'transcurren 4 horas de atención',
        entonces: 'el sistema continúa calculando y registrando compras con normalidad'
      }
    ],
    rnfs: [
      { category: 'Fiabilidad – Tolerancia a fallos', detail: 'RNF-02: Operar sin conexión toda la jornada (mínimo ≥ 4 h) y sincronizar 100 % en ≤ 5 min.' },
      { category: 'Seguridad – Integridad', detail: 'RNF-03: 0 compras perdidas o duplicadas al sincronizar ambas ventanillas.' }
    ],
    uiNote: 'Indicador permanente “Con conexión / Sin conexión” y contador visible de compras pendientes por sincronizar.',
    invest: { I: false, N: true, V: true, E: true, S: true, T: true }
  },
  {
    id: 'HU-11',
    title: 'Retomar una compra interrumpida',
    epic: 'Continuidad operativa',
    role: 'Operadora de ventanilla',
    moscow: 'S',
    points: 5,
    businessValue: 'Medio',
    techRisk: 'Medio',
    dependsOn: 'HU-03',
    source: 'RNF-04 · ENT-01 (DEC-01-16, pregunta 38)',
    card: {
      como: 'operadora de ventanilla',
      quiero: 'que, tras un corte de energía o un cierre inesperado, el sistema me muestre la compra que estaba registrando con la cotización aplicada',
      para: 'terminarla sin volver a pedir los datos al cliente'
    },
    rules: [
      { id: 'RN-01', text: 'Al retomar, E1 necesita principalmente la cotización con la que estaba calculando (DEC-01-16).' },
      { id: 'RN-02', text: 'Solo se recupera la compra no confirmada; las confirmadas ya están persistidas.' },
      { id: 'RN-03', text: 'La operadora decide si continúa la operación recuperada o la descarta.' },
      { id: 'RN-04', text: 'Si la tasa cambió mientras el sistema estuvo cerrado, la regla de precedencia se valida en P-01.' }
    ],
    criteria: [
      {
        id: 'CA-01',
        name: 'Recuperación',
        dado: 'hay una compra en curso de EUR 250 con tasa 1,08 sin confirmar',
        cuando: 'el sistema se cierra inesperadamente y se vuelve a abrir',
        entonces: 'muestra divisa, cantidad y tasa en ≤ 1 min desde el reinicio'
      },
      {
        id: 'CA-02',
        name: 'Descartar',
        dado: 'el sistema muestra una compra recuperada',
        cuando: 'la operadora elige descartar',
        entonces: 'no se registra ninguna compra'
      },
      {
        id: 'CA-03',
        name: 'La tasa cambió',
        dado: 'mientras el sistema estaba cerrado la tasa del euro pasó a 1,06',
        cuando: 'la operadora retoma la compra',
        entonces: 'muestra ambas tasas y no permite confirmar hasta que elija una'
      }
    ],
    rnfs: [
      { category: 'Fiabilidad – Recuperación', detail: 'RNF-04: 100 % de compras en curso recuperadas en ≤ 1 min (mínimo ≤ 3 min) en 10 interrupciones forzadas.' }
    ],
    uiNote: 'Al iniciar, aviso automático “Compra pendiente” con acciones claras: “Continuar” y “Descartar”.',
    invest: { I: false, N: true, V: true, E: true, S: true, T: true }
  },
  {
    id: 'HU-12',
    title: 'Registrar el capital inicial de la jornada',
    epic: 'Caja y cierre',
    role: 'Operadora de ventanilla',
    moscow: 'M',
    points: 2,
    businessValue: 'Alto',
    techRisk: 'Bajo',
    dependsOn: 'Ninguna',
    source: 'RF-08 · ENT-01 (DEC-01-12, DEC-01-24, pregunta 21)',
    card: {
      como: 'operadora de ventanilla',
      quiero: 'registrar al abrir el efectivo en dólares que me entrega la propietaria',
      para: 'controlar cuánto puedo pagar y cuadrar la caja al cierre'
    },
    rules: [
      { id: 'RN-01', text: 'El cuadre diario se realiza tomando como base el capital entregado por la propietaria (pregunta 21).' },
      { id: 'RN-02', text: 'Se registra un capital inicial por jornada; cualquier modificación posterior exige motivo.' },
      { id: 'RN-03', text: 'La atención al público inicia a las 08:30 (DEC-01-02).' }
    ],
    criteria: [
      {
        id: 'CA-01',
        name: 'Registro del capital',
        dado: 'la jornada no tiene capital registrado',
        cuando: 'la operadora registra USD 5.000,00',
        entonces: 'se guarda con fecha-hora y usuario y se muestra como efectivo disponible'
      },
      {
        id: 'CA-02',
        name: 'Compra sin capital',
        dado: 'la jornada aún no tiene capital registrado',
        cuando: 'la operadora intenta confirmar una compra',
        entonces: 'el sistema solicita registrar primero el capital inicial'
      },
      {
        id: 'CA-03',
        name: 'Valor inválido',
        dado: 'la operadora está registrando el capital',
        cuando: 'ingresa 0 o un valor negativo',
        entonces: 'no guarda y señala el campo con error'
      }
    ],
    rnfs: [
      { category: 'Operabilidad', detail: 'Registrar el capital inicial deberá tomar ≤ 1 min sin asistencia.' },
      { category: 'Seguridad – Responsabilidad', detail: '100 % de cambios al capital registrados con usuario, fecha-hora y motivo.' }
    ],
    uiNote: 'Pantalla “Apertura de jornada” mostrada automáticamente al iniciar el día si no existe capital registrado.',
    invest: { I: true, N: true, V: true, E: true, S: true, T: true }
  },
  {
    id: 'HU-13',
    title: 'Registrar un ingreso adicional de efectivo',
    epic: 'Caja y cierre',
    role: 'Operadora de ventanilla',
    moscow: 'C',
    points: 2,
    businessValue: 'Bajo',
    techRisk: 'Bajo',
    dependsOn: 'HU-12',
    source: 'RF-11 · ENT-01 (DEC-01-24, preguntas 10 y 18)',
    card: {
      como: 'operadora de ventanilla',
      quiero: 'registrar el efectivo adicional que envía la propietaria cuando el capital no alcanza',
      para: 'que el saldo disponible y el cuadre lo incluyan'
    },
    rules: [
      { id: 'RN-01', text: 'La reposición de efectivo la gestiona la propietaria y suele tardar de 30 a 40 min (pregunta 10).' },
      { id: 'RN-02', text: 'Se registra el monto en USD, la fecha-hora exacta y quién entregó el efectivo.' }
    ],
    criteria: [
      {
        id: 'CA-01',
        name: 'Registro del ingreso',
        dado: 'el efectivo disponible es USD 300,00',
        cuando: 'la operadora registra un ingreso adicional de USD 1.000,00',
        entonces: 'el efectivo disponible pasa a USD 1.300,00 en ≤ 2 s'
      },
      {
        id: 'CA-02',
        name: 'Valor inválido',
        dado: 'la operadora está registrando un ingreso',
        cuando: 'ingresa 0 o un valor negativo',
        entonces: 'el sistema no lo guarda y señala el campo con error'
      },
      {
        id: 'CA-03',
        name: 'Incluido en el cuadre',
        dado: 'se registró un ingreso adicional de USD 1.000,00',
        cuando: 'se calcula el cuadre de la jornada',
        entonces: 'el ingreso se suma al capital total de la jornada'
      }
    ],
    rnfs: [
      { category: 'Corrección funcional', detail: '100 % de los ingresos adicionales reflejados sin diferencias en efectivo disponible y cuadre.' }
    ],
    uiNote: 'Acción “Ingreso de efectivo” en pantalla de caja con monto y nombre de la persona que entrega.',
    invest: { I: false, N: true, V: true, E: true, S: true, T: true }
  },
  {
    id: 'HU-14',
    title: 'Registrar los gastos de caja',
    epic: 'Caja y cierre',
    role: 'Operadora de ventanilla',
    moscow: 'M',
    points: 2,
    businessValue: 'Alto',
    techRisk: 'Bajo',
    dependsOn: 'HU-12',
    source: 'RF-16 · ENT-01 (DEC-01-13, preguntas 19 y 20)',
    card: {
      como: 'operadora de ventanilla',
      quiero: 'registrar cada gasto pagado con el efectivo de la caja',
      para: 'que el reporte y el cuadre del día los incluyan'
    },
    rules: [
      { id: 'RN-01', text: 'Si hubo gastos, se reportan; si no existieron, el reporte solo muestra moneda extranjera y efectivo (DEC-01-13).' },
      { id: 'RN-02', text: 'Cada gasto almacena valor en USD, descripción, fecha-hora y usuario.' },
      { id: 'RN-03', text: 'No existen categorías cerradas; se usa descripción libre hasta validarlo con E1 en P-03.' }
    ],
    criteria: [
      {
        id: 'CA-01',
        name: 'Registro de un gasto',
        dado: 'el efectivo disponible es USD 1.000,00',
        cuando: 'registra un gasto de USD 12,50 con descripción “útiles de oficina”',
        entonces: 'se guarda y el efectivo disponible pasa a USD 987,50'
      },
      {
        id: 'CA-02',
        name: 'Datos incompletos',
        dado: 'la operadora está registrando un gasto',
        cuando: 'deja vacía la descripción o ingresa un valor ≤ 0',
        entonces: 'no guarda el registro y señala el campo con error'
      },
      {
        id: 'CA-03',
        name: 'Jornada sin gastos',
        dado: 'no se registró ningún gasto en el día',
        cuando: 'se genera el reporte diario',
        entonces: 'la sección de gastos muestra USD 0,00'
      }
    ],
    rnfs: [
      { category: 'Operabilidad', detail: 'Registrar un gasto de caja deberá tomar ≤ 1 min sin asistencia.' }
    ],
    uiNote: 'Acción “Gasto” en pantalla de caja con valor, descripción y listado de gastos del día.',
    invest: { I: false, N: true, V: true, E: true, S: true, T: true }
  },
  {
    id: 'HU-15',
    title: 'Consolidar las compras de la jornada',
    epic: 'Caja y cierre',
    role: 'Operadora de ventanilla',
    moscow: 'M',
    points: 3,
    businessValue: 'Alto',
    techRisk: 'Bajo',
    dependsOn: 'HU-04',
    source: 'RF-13 · ENT-01 (DEC-01-12, preguntas 14 y 19)',
    card: {
      como: 'operadora de ventanilla',
      quiero: 'ver al cierre el total comprado de cada divisa y su equivalente en dólares, agrupado por tasa aplicada',
      para: 'dejar de sumar a mano lo anotado en el cuaderno'
    },
    rules: [
      { id: 'RN-01', text: 'Al cierre se totaliza cada divisa, se verifican las tasas aplicadas y el efectivo (pregunta 14).' },
      { id: 'RN-02', text: 'Si una misma divisa tuvo varias tasas durante el día, se presenta un subtotal por cada tasa.' },
      { id: 'RN-03', text: 'Incluye las compras de las dos ventanillas y las registradas sin conexión ya sincronizadas.' }
    ],
    criteria: [
      {
        id: 'CA-01',
        name: 'Consolidado por tasa',
        dado: 'se compraron EUR 100 y EUR 150 a 1,08, y EUR 200 a 1,06',
        cuando: 'la operadora abre el consolidado',
        entonces: 've EUR 250 = USD 270,00 (1,08), EUR 200 = USD 212,00 (1,06) y total EUR 450 = USD 482,00'
      },
      {
        id: 'CA-02',
        name: 'Compras sin sincronizar',
        dado: 'existen 2 compras registradas sin conexión pendientes de sincronizar',
        cuando: 'abre el consolidado',
        entonces: 'avisa “2 compras pendientes de sincronizar” e impide cerrar hasta sincronizarlas'
      },
      {
        id: 'CA-03',
        name: 'Exactitud',
        dado: 'hay 50 compras de prueba de distintas divisas',
        cuando: 'se compara el consolidado contra el cálculo de referencia',
        entonces: 'la diferencia es exactamente USD 0,00'
      }
    ],
    rnfs: [
      { category: 'Corrección funcional', detail: 'Totales exactos al centavo frente al cálculo de referencia en el 100 % de las pruebas.' },
      { category: 'Eficiencia temporal', detail: 'Despliegue del consolidado en ≤ 3 s con 300 compras en la jornada.' }
    ],
    uiNote: 'Pantalla “Cierre – consolidado”: tabla agrupada por divisa y tasa (cantidad, USD, N.º de compras y total).',
    invest: { I: false, N: true, V: true, E: true, S: true, T: true }
  },
  {
    id: 'HU-16',
    title: 'Calcular el cuadre de caja',
    epic: 'Caja y cierre',
    role: 'Operadora de ventanilla',
    moscow: 'M',
    points: 5,
    businessValue: 'Alto',
    techRisk: 'Medio',
    dependsOn: 'HU-12, HU-14, HU-15',
    source: 'RF-14 · ENT-01 (DEC-01-12, DEC-01-13, DEC-01-24, pregunta 21)',
    card: {
      como: 'operadora de ventanilla',
      quiero: 'que el sistema compare el capital de la jornada con el efectivo que queda, los dólares pagados por divisas y los gastos',
      para: 'saber si la caja cuadra antes de reportar a la propietaria'
    },
    rules: [
      { id: 'RN-01', text: 'Fórmula: diferencia = efectivo contado + USD pagados + gastos − capital inicial − ingresos adicionales (negativo: faltante; positivo: sobrante).' },
      { id: 'RN-02', text: 'La operadora ingresa el efectivo contado físicamente; el sistema nunca lo asume.' },
      { id: 'RN-03', text: 'Toda diferencia distinta de cero exige registrar una observación antes de cerrar.' },
      { id: 'RN-04', text: 'Las compras marcadas por usar tasa de otro día (HU-10) se listan automáticamente para revisión.' }
    ],
    criteria: [
      {
        id: 'CA-01',
        name: 'Caja cuadrada',
        dado: 'capital USD 5.000,00, compras USD 482,00 y gastos USD 12,50',
        cuando: 'ingresa efectivo contado de USD 4.505,50',
        entonces: 'muestra diferencia USD 0,00 y estado “Cuadrada”'
      },
      {
        id: 'CA-02',
        name: 'Faltante',
        dado: 'el mismo escenario anterior de capital, compras y gastos',
        cuando: 'ingresa efectivo contado de USD 4.495,50',
        entonces: 'muestra “Faltante USD 10,00” y exige una observación antes de cerrar'
      },
      {
        id: 'CA-03',
        name: 'Compras para revisión',
        dado: 'existe 1 compra registrada con tasa de otro día',
        cuando: 'la operadora abre el cuadre',
        entonces: 'el sistema la muestra destacada en la lista “Para revisión”'
      }
    ],
    rnfs: [
      { category: 'Corrección funcional', detail: 'Diferencia calculada exacta al centavo frente al cálculo manual en 100 % de 20 escenarios.' },
      { category: 'Operabilidad', detail: 'Completar el cuadre en el sistema (sin conteo físico) en ≤ 5 min.' }
    ],
    uiNote: 'Pantalla “Cierre – cuadre” con desglose completo, efectivo contado, diferencia, estado y observación.',
    invest: { I: false, N: true, V: true, E: true, S: true, T: true }
  },
  {
    id: 'HU-17',
    title: 'Recibir el reporte diario de la jornada',
    epic: 'Caja y cierre',
    role: 'Propietaria de la casa de cambio',
    moscow: 'M',
    points: 5,
    businessValue: 'Alto',
    techRisk: 'Medio',
    dependsOn: 'HU-14, HU-15, HU-16',
    source: 'RF-15 · ENT-01 (DEC-01-01, DEC-01-12, DEC-01-13, pregunta 20)',
    card: {
      como: 'propietaria de la casa de cambio',
      quiero: 'recibir al cierre de cada jornada un reporte con las divisas compradas, el efectivo en dólares, los gastos y el resultado del cuadre',
      para: 'controlar el negocio aunque no esté en el local'
    },
    rules: [
      { id: 'RN-01', text: 'E1 envía el reporte diariamente a la propietaria, quien reside fuera del país (DEC-01-01, DEC-01-12).' },
      { id: 'RN-02', text: 'Contenido: moneda extranjera por divisa, efectivo nacional, gastos (si hubo) y resultado del cuadre (DEC-01-13).' },
      { id: 'RN-03', text: 'El canal de envío (correo electrónico o descarga) se acuerda con la propietaria en P-03.' },
      { id: 'RN-04', text: 'El reporte no incluye datos personales de clientes.' }
    ],
    criteria: [
      {
        id: 'CA-01',
        name: 'Generación',
        dado: 'la jornada está cuadrada',
        cuando: 'la operadora cierra la jornada',
        entonces: 'genera el reporte en ≤ 10 s con totales por divisa, USD, gastos y cuadre'
      },
      {
        id: 'CA-02',
        name: 'Envío',
        dado: 'el reporte está generado y hay conexión',
        cuando: 'la operadora lo envía',
        entonces: 'la propietaria lo recibe y el sistema registra la fecha-hora de envío'
      },
      {
        id: 'CA-03',
        name: 'Cierre sin conexión',
        dado: 'no hay conexión al momento del cierre',
        cuando: 'la operadora intenta enviar el reporte',
        entonces: 'queda en cola y se envía automáticamente al reconectar, registrando hora real'
      }
    ],
    rnfs: [
      { category: 'Corrección funcional', detail: '100 % de coincidencia entre los totales del reporte, el consolidado y el cuadre.' },
      { category: 'Fiabilidad – Tolerancia a fallos', detail: '100 % de reportes en cola enviados en ≤ 5 min tras recuperar conexión.' }
    ],
    uiNote: 'Botón “Cerrar jornada y enviar reporte”; diseño con resumen ejecutivo superior y detalle por divisa y tasa.',
    invest: { I: false, N: true, V: true, E: true, S: true, T: true }
  },
  {
    id: 'HU-18',
    title: 'Identificar al cliente en compras sobre el umbral de reporte',
    epic: 'Cumplimiento normativo',
    role: 'Propietaria de la casa de cambio',
    moscow: 'W',
    points: 8,
    businessValue: 'Alto',
    techRisk: 'Alto',
    dependsOn: 'HU-04 y cierre de P-02',
    source: 'RN-03 · ENT-01 (DEC-01-11, preguntas 15, 16 y 42; problema 6 y conflicto 13)',
    card: {
      como: 'propietaria de la casa de cambio',
      quiero: 'que el sistema pida la identificación del cliente solo en las compras que alcancen el umbral de reporte a la UAFE',
      para: 'cumplir la normativa sin demorar las compras ordinarias'
    },
    rules: [
      { id: 'RN-01', text: 'Actualmente no se solicitan datos del cliente (DEC-01-11).' },
      { id: 'RN-02', text: 'La ley antilavado 2024 incluye a casas de cambio como sujetos obligados UAFE (umbral ref.: USD 10.000 por operación o acumulado en 30 días, a confirmar en P-02).' },
      { id: 'RN-03', text: 'En compras bajo el umbral no se capturan datos personales (principio de minimización LOPDP).' },
      { id: 'RN-04', text: 'Es prioridad W hasta cerrar P-02; si se confirma la obligación legal, asciende a M.' }
    ],
    criteria: [
      {
        id: 'CA-01',
        name: 'Compra sobre el umbral',
        dado: 'el umbral configurado es USD 10.000,00',
        cuando: 'la operadora calcula una compra de USD 10.500,00',
        entonces: 'exige tipo y número de documento del cliente antes de confirmar'
      },
      {
        id: 'CA-02',
        name: 'Compra ordinaria',
        dado: 'el umbral configurado es USD 10.000,00',
        cuando: 'calcula una compra de USD 800,00',
        entonces: 'no solicita ningún dato personal del cliente'
      },
      {
        id: 'CA-03',
        name: 'Acceso restringido',
        dado: 'existe una compra con identificación de cliente',
        cuando: 'un usuario sin permiso consulta la operación',
        entonces: 'el sistema oculta el número de documento'
      }
    ],
    rnfs: [
      { category: 'Seguridad – Confidencialidad', detail: '0 datos personales en compras bajo umbral y visibilidad restringida a roles autorizados (100 %).' }
    ],
    uiNote: 'Campos condicionales de tipo y número de documento visibles solo al superar el umbral parametrizable.',
    invest: { I: false, N: true, V: true, E: false, S: true, T: true }
  }
];
