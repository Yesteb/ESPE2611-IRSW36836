/**
 * ============================================================================
 * DATOS DE CONTEXTO, FLUJO DE COMPRA DE DIVISAS, STAKEHOLDERS Y TRAZABILIDAD
 * ============================================================================
 */
window.PresentationApp = window.PresentationApp || {};

window.PresentationApp.CONTEXT = {
  kpis: [
    {
      value: '18',
      label: 'Historias de Usuario',
      desc: '17 cubren RF-01 a RF-20 y HU-18 atiende la regla candidata RN-03.',
      accent: ''
    },
    {
      value: '20',
      label: 'Requisitos Funcionales',
      desc: 'Elicitados en la entrevista ENT-01 (v1.1 validada el 18/11/2026).',
      accent: ''
    },
    {
      value: '6+',
      label: 'Divisas Operadas',
      desc: 'EUR, COP, PEN (principales), BRL, GBP y CLP hacia USD en efectivo.',
      accent: 'is-gold'
    },
    {
      value: '2',
      label: 'Ventanillas Concurrentes',
      desc: 'Atención simultánea con soporte offline y cuadre unificado diario.',
      accent: 'is-red'
    }
  ],
  threeC: [
    {
      code: '1C',
      title: 'Tarjeta (Card)',
      desc: 'Enunciado conciso Como / Quiero / Para que captura el rol, la necesidad operativa y el valor para la casa de cambio.'
    },
    {
      code: '2C',
      title: 'Conversación (Conversation)',
      desc: 'Reglas de negocio, fórmulas de conversión y acuerdos aclarados con E1 en ENT-01 y puntos por validar (P-01 a P-12).'
    },
    {
      code: '3C',
      title: 'Confirmación (Confirmation)',
      desc: 'Criterios de aceptación verificables en formato Gherkin (Dado / Cuando / Entonces) y restricciones ISO/IEC 25010.'
    }
  ],
  moscowSummary: [
    { code: 'M', count: 9, label: 'Debe tener (Must)', desc: 'Núcleo operativo: tasas, cálculo USD, registro, operación sin Internet y cierre.' },
    { code: 'S', count: 5, label: 'Debería (Should)', desc: 'Controles de efectivo, autorización alto monto, nota de venta, cotización y recuperación.' },
    { code: 'C', count: 3, label: 'Podría (Could)', desc: 'Mejoras deseables: corrección auditable, búsqueda filtrada e ingresos adicionales.' },
    { code: 'W', count: 1, label: 'No por ahora (Won’t)', desc: 'HU-18 (identificación UAFE), condicionada a confirmación normativa en P-02.' }
  ],
  fxFlow: {
    steps: [
      {
        num: 'PASO 01',
        title: 'Apertura y Tasas',
        desc: 'Inicio 08:30. Registro de capital inicial en USD y tasas autorizadas del día (con referencia global).',
        hus: ['HU-01', 'HU-02', 'HU-12'],
        accent: false
      },
      {
        num: 'PASO 02',
        title: 'Cotización en Ventanilla',
        desc: 'Se ingresa divisa y monto entregado por el cliente; cálculo instantáneo en USD (× o ÷) en ≤ 1 s.',
        hus: ['HU-03'],
        accent: false
      },
      {
        num: 'PASO 03',
        title: 'Controles Previos',
        desc: 'Validación de efectivo disponible, autorización por alto monto/tasa especial y umbral UAFE.',
        hus: ['HU-05', 'HU-06', 'HU-18'],
        accent: true
      },
      {
        num: 'PASO 04',
        title: 'Pago y Registro',
        desc: 'Pago únicamente en USD en efectivo, confirmación digital (incluso sin Internet) y nota de venta.',
        hus: ['HU-04', 'HU-07', 'HU-10', 'HU-11'],
        accent: false
      },
      {
        num: 'PASO 05',
        title: 'Consolidado y Cierre',
        desc: 'Gastos, ingresos adicionales, consolidado por tasa, cuadre de caja y envío de reporte diario.',
        hus: ['HU-13', 'HU-14', 'HU-15', 'HU-16', 'HU-17'],
        accent: true
      }
    ],
    currencies: [
      { code: 'EUR €', name: 'Euro', op: 'Multiplica (×)', freq: 'Alta frecuencia' },
      { code: 'COP $', name: 'Peso Colombiano', op: 'Divide (÷)', freq: 'Alta frecuencia' },
      { code: 'PEN S/', name: 'Sol Peruano', op: 'Divide (÷)', freq: 'Alta frecuencia' },
      { code: 'BRL R$', name: 'Real Brasileño', op: 'Según tasa', freq: 'Menor frecuencia' },
      { code: 'GBP £', name: 'Libra Esterlina', op: 'Multiplica (×)', freq: 'Menor frecuencia' },
      { code: 'CLP $', name: 'Peso Chileno', op: 'Divide (÷)', freq: 'Menor frecuencia' }
    ],
    keyRules: [
      { title: 'Pago exclusivo en efectivo (RN-01)', text: 'Todas las compras de divisa extranjera se liquidan únicamente en dólares estadounidenses (USD) en efectivo.' },
      { title: 'Tasa autorizada inmutable (RN-02)', text: 'Solo la propietaria fija tasas; un cambio intradía no altera compras ya confirmadas.' },
      { title: 'Resiliencia operativa (RNF-02 / RNF-03)', text: 'Ambas ventanillas operan simultáneamente incluso ante cortes de Internet (≥ 4 h) o energía.' },
      { title: 'Privacidad y cumplimiento (RN-03)', text: 'Sin captura de datos personales en compras ordinarias (LOPDP); identificación solo sobre umbral UAFE.' }
    ]
  },
  stakeholders: {
    internal: [
      {
        name: 'Propietaria de la casa de cambio',
        tag: 'Decisor de negocio',
        desc: 'Define y autoriza las tasas diarias, aprueba compras de alto monto o tasas especiales y recibe el reporte diario de cierre a distancia.'
      },
      {
        name: 'Operadoras de ventanilla (incluye E1)',
        tag: 'Usuario final operativo',
        desc: 'Atienden presencialmente en las dos ventanillas: calculan equivalentes en USD, confirman compras, gestionan efectivo y cuadran la caja.'
      },
      {
        name: 'Equipo de Ingeniería de Requisitos (Grupo N.º 6)',
        tag: 'Equipo de desarrollo',
        desc: 'Responsable de elicitar, analizar, especificar en formato 3C, verificar calidad INVEST y mantener trazabilidad contra ENT-01.'
      }
    ],
    external: [
      {
        name: 'Clientes de la casa de cambio',
        tag: 'Beneficiario directo',
        desc: 'Entregan divisa extranjera y reciben el equivalente en dólares en efectivo; pueden solicitar nota de venta sin registro de datos en compras ordinarias.'
      },
      {
        name: 'Ente regulador (UAFE) y marco LOPDP',
        tag: 'Entorno normativo',
        desc: 'La Ley Antilavado 2024 establece umbral de reporte (ref. USD 10.000) y la LOPDP exige minimización de datos personales en operaciones menores.'
      },
      {
        name: 'Proveedores de cotización global',
        tag: 'Fuente externa de referencia',
        desc: 'Sitio o servicio externo consultado en HU-02 únicamente como referencia para apoyar la decisión de la tasa del día (a definir en P-09).'
      }
    ]
  },
  traceability: [
    { req: 'RF-01', hus: ['HU-04'] },
    { req: 'RF-02', hus: ['HU-03'] },
    { req: 'RF-03', hus: ['HU-03'] },
    { req: 'RF-04', hus: ['HU-01'] },
    { req: 'RF-05', hus: ['HU-01', 'HU-04'] },
    { req: 'RF-06', hus: ['HU-02'] },
    { req: 'RF-07', hus: ['HU-10'] },
    { req: 'RF-08', hus: ['HU-12'] },
    { req: 'RF-09', hus: ['HU-05'] },
    { req: 'RF-10', hus: ['HU-05'] },
    { req: 'RF-11', hus: ['HU-13'] },
    { req: 'RF-12', hus: ['HU-07'] },
    { req: 'RF-13', hus: ['HU-15'] },
    { req: 'RF-14', hus: ['HU-16'] },
    { req: 'RF-15', hus: ['HU-17'] },
    { req: 'RF-16', hus: ['HU-14'] },
    { req: 'RF-17', hus: ['HU-09'] },
    { req: 'RF-18', hus: ['HU-06'] },
    { req: 'RF-19', hus: ['HU-08'] },
    { req: 'RF-20', hus: ['HU-10'] },
    { req: 'RNF-01a', hus: ['HU-03'] },
    { req: 'RNF-01b', hus: ['HU-04'] },
    { req: 'RNF-02', hus: ['HU-10'] },
    { req: 'RNF-03', hus: ['HU-04', 'HU-10'] },
    { req: 'RNF-04', hus: ['HU-11'] },
    { req: 'RNF-05', hus: ['HU-03'] },
    { req: 'RNF-06', hus: ['HU-01', 'HU-08'] },
    { req: 'RES-01', text: 'Todas (interfaz para computadora)' },
    { req: 'RN-01', hus: ['HU-04'] },
    { req: 'RN-02', hus: ['HU-01'] },
    { req: 'RN-03', hus: ['HU-18'] }
  ],
  traceNote: 'Los valores numéricos no declarados por E1 (tiempos de respuesta o umbral de prueba de USD 2.000,00) son propuestas técnicas a validar en P-03. Las tasas usadas en los criterios Gherkin son datos de prueba.'
};
