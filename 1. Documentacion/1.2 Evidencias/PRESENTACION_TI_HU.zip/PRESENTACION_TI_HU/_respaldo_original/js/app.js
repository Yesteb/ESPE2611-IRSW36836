/**
 * ============================================================================
 * MOTOR DE LA PRESENTACIÓN
 * Ensambla las 25 diapositivas modulares, escala 16:9 sin recortes,
 * controla navegación, índice lateral y pantalla completa.
 * ============================================================================
 */
(function initPresentation() {
  const App = window.PresentationApp;
  const { Renderers, STORIES } = App;

  const stageEl = document.getElementById('deck-stage');
  const progressBarEl = document.getElementById('deck-progress-bar');
  const counterEl = document.getElementById('ctrl-counter');
  const prevBtn = document.getElementById('btn-prev');
  const nextBtn = document.getElementById('btn-next');
  const indexBtn = document.getElementById('btn-index');
  const fullscreenBtn = document.getElementById('btn-fullscreen');
  const drawerEl = document.getElementById('nav-drawer');
  const drawerBackdrop = document.getElementById('nav-drawer-backdrop');
  const drawerCloseBtn = document.getElementById('drawer-close');
  const drawerListEl = document.getElementById('nav-drawer-list');
  const drawerSearchEl = document.getElementById('nav-drawer-search');

  // 1. Ensamblar todas las diapositivas en orden (25 total)
  const totalSlides = 5 + STORIES.length + 2; // Portada + Contexto + Flujo Divisas + Stakeholders + Épicas + 18 HUs + Trazabilidad + Cierre
  const slidesHtml = [
    Renderers.coverSlide(),
    Renderers.contextSlide(2, totalSlides),
    Renderers.fxFlowSlide(3, totalSlides),
    Renderers.stakeholdersSlide(4, totalSlides),
    Renderers.epicsSlide(5, totalSlides),
    ...STORIES.map((story, idx) => Renderers.storySlide(story, 6 + idx, totalSlides)),
    Renderers.traceabilitySlide(6 + STORIES.length, totalSlides),
    Renderers.closingSlide()
  ];

  stageEl.innerHTML = slidesHtml.join('\n');

  const slideEls = Array.from(stageEl.querySelectorAll('.slide'));
  const storyIndexMap = new Map();
  slideEls.forEach((el, idx) => {
    const storyId = el.getAttribute('data-story-id');
    if (storyId) storyIndexMap.set(storyId, idx);
  });

  let currentIndex = 0;

  // 2. Escalado proporcional 16:9 respetando siempre la franja de controles inferior
  function scaleStage() {
    const padX = 32;
    const padY = 76; // 12px arriba + 60px abajo + margen de seguridad
    const availW = Math.max(320, window.innerWidth - padX);
    const availH = Math.max(240, window.innerHeight - padY);
    const scale = Math.min(availW / 1280, availH / 720);
    stageEl.style.transform = `scale(${scale})`;
  }

  // 3. Cambio de diapositiva
  function goTo(index, updateHash = true) {
    const clamped = Math.max(0, Math.min(slideEls.length - 1, index));
    currentIndex = clamped;

    slideEls.forEach((el, i) => {
      el.classList.toggle('is-active', i === currentIndex);
      el.classList.toggle('is-prev', i < currentIndex);
    });

    const humanNum = String(currentIndex + 1).padStart(2, '0');
    const humanTotal = String(slideEls.length).padStart(2, '0');
    counterEl.textContent = `${humanNum} / ${humanTotal}`;
    progressBarEl.style.width = `${((currentIndex + 1) / slideEls.length) * 100}%`;

    prevBtn.disabled = currentIndex === 0;
    nextBtn.disabled = currentIndex === slideEls.length - 1;

    if (updateHash) {
      const storyId = slideEls[currentIndex].getAttribute('data-story-id');
      const targetHash = storyId ? `#${storyId}` : `#slide-${currentIndex + 1}`;
      history.replaceState(null, '', targetHash);
    }

    updateDrawerHighlight();
  }

  function goToStory(storyId) {
    if (storyIndexMap.has(storyId)) {
      goTo(storyIndexMap.get(storyId));
      closeDrawer();
    }
  }

  // 4. Índice lateral interactivo con buscador
  function buildDrawer(filterText = '') {
    const query = filterText.trim().toLowerCase();
    drawerListEl.innerHTML = slideEls
      .map((el, idx) => {
        const title = el.getAttribute('data-slide-title') || `Diapositiva ${idx + 1}`;
        const group = el.getAttribute('data-slide-group') || '';
        const haystack = `${idx + 1} ${title} ${group}`.toLowerCase();
        if (query && !haystack.includes(query)) return '';
        return `
          <button type="button" class="drawer-item ${idx === currentIndex ? 'is-current' : ''}" data-slide-index="${idx}">
            <span class="drawer-item-num">${String(idx + 1).padStart(2, '0')}</span>
            <div class="drawer-item-body">
              <div class="drawer-item-title">${title}</div>
              <div class="drawer-item-sub">${group}</div>
            </div>
          </button>
        `;
      })
      .join('');
  }

  function updateDrawerHighlight() {
    drawerListEl.querySelectorAll('.drawer-item').forEach((btn) => {
      const idx = Number(btn.getAttribute('data-slide-index'));
      btn.classList.toggle('is-current', idx === currentIndex);
    });
  }

  function openDrawer() {
    drawerEl.classList.add('is-open');
    drawerBackdrop.classList.add('is-open');
    drawerSearchEl.focus();
  }

  function closeDrawer() {
    drawerEl.classList.remove('is-open');
    drawerBackdrop.classList.remove('is-open');
  }

  // 5. Pantalla completa
  function toggleFullscreen() {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen?.().catch(() => {});
    } else {
      document.exitFullscreen?.().catch(() => {});
    }
  }

  // 6. Eventos de UI y teclado
  prevBtn.addEventListener('click', () => goTo(currentIndex - 1));
  nextBtn.addEventListener('click', () => goTo(currentIndex + 1));
  indexBtn.addEventListener('click', () => {
    if (drawerEl.classList.contains('is-open')) closeDrawer();
    else openDrawer();
  });
  drawerCloseBtn.addEventListener('click', closeDrawer);
  drawerBackdrop.addEventListener('click', closeDrawer);
  fullscreenBtn.addEventListener('click', toggleFullscreen);

  drawerSearchEl.addEventListener('input', (e) => buildDrawer(e.target.value));

  drawerListEl.addEventListener('click', (e) => {
    const btn = e.target.closest('.drawer-item');
    if (!btn) return;
    goTo(Number(btn.getAttribute('data-slide-index')));
    closeDrawer();
  });

  // Delegación de clics para saltar a cualquier HU desde Flujo, Épicas o Trazabilidad
  stageEl.addEventListener('click', (e) => {
    const trigger = e.target.closest('[data-goto-story]');
    if (!trigger) return;
    goToStory(trigger.getAttribute('data-goto-story'));
  });

  document.addEventListener('keydown', (e) => {
    if (document.activeElement === drawerSearchEl) {
      if (e.key === 'Escape') closeDrawer();
      return;
    }
    if (e.key === 'ArrowRight' || e.key === 'PageDown' || e.key === ' ') {
      e.preventDefault();
      goTo(currentIndex + 1);
    } else if (e.key === 'ArrowLeft' || e.key === 'PageUp') {
      e.preventDefault();
      goTo(currentIndex - 1);
    } else if (e.key === 'Home') {
      e.preventDefault();
      goTo(0);
    } else if (e.key === 'End') {
      e.preventDefault();
      goTo(slideEls.length - 1);
    } else if (e.key === 'f' || e.key === 'F') {
      e.preventDefault();
      toggleFullscreen();
    } else if (e.key === 'g' || e.key === 'G' || e.key === 'm' || e.key === 'M') {
      e.preventDefault();
      if (drawerEl.classList.contains('is-open')) closeDrawer();
      else openDrawer();
    } else if (e.key === 'Escape') {
      closeDrawer();
    }
  });

  window.addEventListener('resize', scaleStage);

  function resolveInitialIndex() {
    const hash = window.location.hash.replace('#', '');
    if (!hash) return 0;
    if (storyIndexMap.has(hash.toUpperCase())) return storyIndexMap.get(hash.toUpperCase());
    const match = hash.match(/^slide-(\d+)$/i);
    if (match) return Math.max(0, Math.min(slideEls.length - 1, Number(match[1]) - 1));
    return 0;
  }

  buildDrawer();
  scaleStage();
  goTo(resolveInitialIndex(), false);
})();
